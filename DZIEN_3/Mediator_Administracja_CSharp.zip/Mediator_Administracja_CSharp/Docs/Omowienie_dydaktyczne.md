# Omówienie dydaktyczne: wzorzec Mediator

## Cel projektu

Projekt pokazuje wzorzec **Mediator** w systemie administracyjnym. Wniosek jest obsługiwany przez kilka komponentów, ale komponenty nie wywołują się bezpośrednio. Współpracę koordynuje mediator.

## Najkrótsza definicja

Mediator wprowadza obiekt pośredniczący, który koordynuje komunikację między komponentami.

Zamiast:

```text
A -> B
A -> C
B -> D
C -> E
```

mamy:

```text
A, B, C, D, E -> Mediator
```

## Kolejność omawiania plików

1. `Models/Wniosek.cs`
2. `Models/WynikWalidacji.cs`
3. `Components/WalidatorWniosku.cs`
4. `Components/RejestrSpraw.cs`
5. `Components/GeneratorDecyzji.cs`
6. `Components/Archiwum.cs`
7. `Components/Powiadomienia.cs`
8. `Components/HistoriaOperacji.cs`
9. `Mediators/ISprawaMediator.cs`
10. `Mediators/SprawaMediator.cs`
11. `Infrastructure/SprawaApplication.cs`
12. `Program.cs`

## Najważniejszy plik

`Mediators/SprawaMediator.cs`

To tam widać właściwy wzorzec. Mediator wywołuje kolejno:

```text
walidator -> rejestr -> generator decyzji -> archiwum -> powiadomienia -> historia
```

## Najważniejsza puenta

Komponenty robią małe rzeczy i nie znają siebie nawzajem. Mediator zna proces i wie, kiedy który komponent uruchomić.

## Co pokazać na debugowaniu?

Ustaw breakpointy:

1. `Program.cs` przy `app.Obsluz(wniosek);`
2. `SprawaApplication.cs` przy `_mediator.ZlozWniosek(wniosek);`
3. `SprawaMediator.cs` w metodzie `ZlozWniosek`
4. `WalidatorWniosku.cs` w metodzie `Sprawdz`
5. `RejestrSpraw.cs` w metodzie `Zarejestruj`
6. `Powiadomienia.cs` w metodzie `Wyslij`

## Pytanie do kursantów

Co by się stało, gdyby `WalidatorWniosku` sam wysyłał powiadomienia, sam zapisywał do archiwum i sam zmieniał statusy? Odpowiedź: powstałaby pajęczyna zależności i naruszenie SRP.
