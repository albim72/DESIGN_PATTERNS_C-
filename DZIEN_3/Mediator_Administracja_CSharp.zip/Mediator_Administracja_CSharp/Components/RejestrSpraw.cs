using MediatorAdministracja.Models;

namespace MediatorAdministracja.Components;

/// <summary>
/// Komponent rejestru spraw.
/// Odpowiada tylko za nadanie numeru sprawy i zmianę statusu.
/// Nie zna walidatora, archiwum ani powiadomień.
/// </summary>
public class RejestrSpraw
{
    public void Zarejestruj(Wniosek wniosek)
    {
        wniosek.NumerSprawy = $"ZUS/{DateTime.Now:yyyy}/{wniosek.Id:000}";
        wniosek.Status = "Zarejestrowany";

        Console.WriteLine($"Rejestr: zarejestrowano sprawę {wniosek.NumerSprawy}.");
    }
}
