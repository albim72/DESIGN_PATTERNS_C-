namespace MediatorAdministracja.Components;

/// <summary>
/// Komponent powiadomień.
/// Odpowiada tylko za wysłanie komunikatu do obywatela.
/// </summary>
public class Powiadomienia
{
    public void Wyslij(string odbiorca, string tresc)
    {
        Console.WriteLine($"Powiadomienia: wysłano do {odbiorca}: {tresc}");
    }
}
