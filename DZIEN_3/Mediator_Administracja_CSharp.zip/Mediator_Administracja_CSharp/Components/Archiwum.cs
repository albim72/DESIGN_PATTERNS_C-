using MediatorAdministracja.Models;

namespace MediatorAdministracja.Components;

/// <summary>
/// Komponent archiwum.
/// Odpowiada tylko za zapis śladu sprawy.
/// </summary>
public class Archiwum
{
    public void Zapisz(Wniosek wniosek)
    {
        Console.WriteLine($"Archiwum: zapisano wniosek #{wniosek.Id} i aktualny status: {wniosek.Status}.");
    }
}
