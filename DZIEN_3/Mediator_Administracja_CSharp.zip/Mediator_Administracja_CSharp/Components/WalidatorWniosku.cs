using MediatorAdministracja.Models;

namespace MediatorAdministracja.Components;

/// <summary>
/// Komponent współpracujący z mediatorem.
/// Odpowiada tylko za walidację formalną wniosku.
/// Nie zna rejestru, archiwum ani powiadomień.
/// </summary>
public class WalidatorWniosku
{
    public WynikWalidacji Sprawdz(Wniosek wniosek)
    {
        Console.WriteLine("Walidator: sprawdzam dane formalne i kompletność dokumentów...");

        if (string.IsNullOrWhiteSpace(wniosek.Obywatel))
        {
            return WynikWalidacji.Blad("Brak danych obywatela.");
        }

        if (string.IsNullOrWhiteSpace(wniosek.Pesel) || wniosek.Pesel.Length != 11)
        {
            return WynikWalidacji.Blad("PESEL jest pusty albo ma nieprawidłową długość.");
        }

        if (!wniosek.DokumentyKompletne)
        {
            return WynikWalidacji.Blad("Dokumenty są niekompletne.");
        }

        return WynikWalidacji.Sukces("Wniosek przeszedł walidację formalną.");
    }
}
