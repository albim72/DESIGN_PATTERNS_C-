namespace MediatorAdministracja.Components;

/// <summary>
/// Komponent historii operacji.
/// Odpowiada za zapis działań wykonywanych w procesie.
/// </summary>
public class HistoriaOperacji
{
    private readonly List<string> _wpisy = new();

    public void Dodaj(string wpis)
    {
        string pelnyWpis = $"{DateTime.Now:HH:mm:ss} | {wpis}";
        _wpisy.Add(pelnyWpis);
        Console.WriteLine($"Historia: {wpis}");
    }

    public void Wypisz()
    {
        Console.WriteLine("\n===== HISTORIA OPERACJI =====");
        foreach (string wpis in _wpisy)
        {
            Console.WriteLine(wpis);
        }
        Console.WriteLine("=============================\n");
    }
}
