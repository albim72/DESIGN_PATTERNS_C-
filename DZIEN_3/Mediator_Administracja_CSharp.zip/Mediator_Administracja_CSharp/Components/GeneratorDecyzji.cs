using MediatorAdministracja.Models;

namespace MediatorAdministracja.Components;

/// <summary>
/// Komponent generujący treść decyzji.
/// W prawdziwym systemie mógłby tworzyć PDF albo dokument DOCX.
/// </summary>
public class GeneratorDecyzji
{
    public void Wygeneruj(Wniosek wniosek)
    {
        if (!wniosek.WymagaDecyzji)
        {
            Console.WriteLine("Generator decyzji: decyzja nie jest wymagana dla tego typu sprawy.");
            return;
        }

        wniosek.Decyzja = $"Decyzja dla sprawy {wniosek.NumerSprawy}: przyjęto wniosek typu '{wniosek.TypSprawy}' do dalszego rozpatrzenia.";

        Console.WriteLine("Generator decyzji: wygenerowano projekt decyzji administracyjnej.");
    }
}
