# Mediator_Administracja_CSharp

Projekt demonstracyjny C# / .NET 8 pokazujący wzorzec projektowy **Mediator** na przykładzie systemu obsługi wniosków administracyjnych.

## Co pokazuje aplikacja?

Program symuluje obsługę wniosków administracyjnych. W procesie biorą udział komponenty:

- `WalidatorWniosku`
- `RejestrSpraw`
- `GeneratorDecyzji`
- `Archiwum`
- `Powiadomienia`
- `HistoriaOperacji`

Komponenty **nie wywołują się bezpośrednio**. Ich współpracę koordynuje `SprawaMediator`.

## Główna idea wzorca

Bez mediatora komponenty zaczęłyby tworzyć pajęczynę zależności:

```text
Walidator -> Powiadomienia
Rejestr -> Archiwum
GeneratorDecyzji -> Historia
Program -> każdy komponent osobno
```

Mediator upraszcza komunikację:

```text
Program -> SprawaApplication -> ISprawaMediator -> komponenty
```

## Struktura projektu

```text
Mediator_Administracja_CSharp/
├── Models/
│   ├── Wniosek.cs
│   └── WynikWalidacji.cs
├── Components/
│   ├── WalidatorWniosku.cs
│   ├── RejestrSpraw.cs
│   ├── GeneratorDecyzji.cs
│   ├── Archiwum.cs
│   ├── Powiadomienia.cs
│   └── HistoriaOperacji.cs
├── Mediators/
│   ├── ISprawaMediator.cs
│   └── SprawaMediator.cs
├── Infrastructure/
│   └── SprawaApplication.cs
├── Docs/
│   └── Omowienie_dydaktyczne.md
├── Program.cs
├── Mediator_Administracja_CSharp.csproj
└── Mediator_Administracja_CSharp.sln
```

## Jak uruchomić?

W Visual Studio otwórz plik:

```text
Mediator_Administracja_CSharp.sln
```

Następnie uruchom projekt przyciskiem Start lub `Ctrl + F5`.

Z terminala:

```bash
dotnet run
```

## Najważniejsze klasy

- `ISprawaMediator` - interfejs mediatora.
- `SprawaMediator` - konkretna klasa mediatora, koordynuje proces obsługi wniosku.
- `SprawaApplication` - warstwa aplikacyjna korzystająca tylko z mediatora.
- `WalidatorWniosku`, `RejestrSpraw`, `Archiwum`, `Powiadomienia` - komponenty współpracujące przez mediatora.

## Pytania kontrolne

1. Która klasa pełni rolę mediatora?
2. Dlaczego `WalidatorWniosku` nie zna klasy `Powiadomienia`?
3. Co zyskujemy dzięki `ISprawaMediator`?
4. Czym Mediator różni się od Fasady?
5. Czym Mediator różni się od Chain of Responsibility?
