using MediatorAdministracja.Components;
using MediatorAdministracja.Infrastructure;
using MediatorAdministracja.Mediators;
using MediatorAdministracja.Models;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.WriteLine("==============================================");
Console.WriteLine(" WZORZEC MEDIATOR - SYSTEM ADMINISTRACYJNY");
Console.WriteLine("==============================================");
Console.WriteLine();

// Komponenty nie znają siebie nawzajem.
// Każdy odpowiada za swoją małą część procesu.
WalidatorWniosku walidator = new();
RejestrSpraw rejestr = new();
GeneratorDecyzji generatorDecyzji = new();
Archiwum archiwum = new();
Powiadomienia powiadomienia = new();
HistoriaOperacji historia = new();

// Mediator zna komponenty i koordynuje ich współpracę.
ISprawaMediator mediator = new SprawaMediator(
    walidator,
    rejestr,
    generatorDecyzji,
    archiwum,
    powiadomienia,
    historia
);

// Warstwa aplikacyjna korzysta tylko z mediatora.
SprawaApplication app = new(mediator);

List<Wniosek> wnioski = new()
{
    new Wniosek(
        id: 1,
        obywatel: "Jan Kowalski",
        pesel: "44051401359",
        typSprawy: "Świadczenie emerytalne",
        dokumentyKompletne: true,
        wymagaDecyzji: true),

    new Wniosek(
        id: 2,
        obywatel: "Anna Nowak",
        pesel: "12345678901",
        typSprawy: "Dodatek mieszkaniowy",
        dokumentyKompletne: false,
        wymagaDecyzji: true),

    new Wniosek(
        id: 3,
        obywatel: "Piotr Zieliński",
        pesel: "98765432109",
        typSprawy: "Aktualizacja danych",
        dokumentyKompletne: true,
        wymagaDecyzji: false)
};

foreach (Wniosek wniosek in wnioski)
{
    app.Obsluz(wniosek);
}

historia.Wypisz();

Console.WriteLine("Koniec demonstracji wzorca Mediator.");
