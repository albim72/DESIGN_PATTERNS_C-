namespace MediatorAdministracja.Models;

/// <summary>
/// Model sprawy administracyjnej.
/// To dane, które przepływają przez proces obsługi wniosku.
/// </summary>
public class Wniosek
{
    public int Id { get; }
    public string Obywatel { get; }
    public string Pesel { get; }
    public string TypSprawy { get; }
    public bool DokumentyKompletne { get; }
    public bool WymagaDecyzji { get; }
    public string Status { get; set; }
    public string? NumerSprawy { get; set; }
    public string? Decyzja { get; set; }

    public Wniosek(
        int id,
        string obywatel,
        string pesel,
        string typSprawy,
        bool dokumentyKompletne,
        bool wymagaDecyzji)
    {
        Id = id;
        Obywatel = obywatel;
        Pesel = pesel;
        TypSprawy = typSprawy;
        DokumentyKompletne = dokumentyKompletne;
        WymagaDecyzji = wymagaDecyzji;
        Status = "Nowy";
    }

    public override string ToString()
    {
        return $"Wniosek #{Id}, obywatel: {Obywatel}, PESEL: {Pesel}, typ sprawy: {TypSprawy}, status: {Status}";
    }
}
