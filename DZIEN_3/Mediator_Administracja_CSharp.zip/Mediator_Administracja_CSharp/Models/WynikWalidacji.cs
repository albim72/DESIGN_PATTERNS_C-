namespace MediatorAdministracja.Models;

/// <summary>
/// Wynik walidacji wniosku.
/// Zamiast zwracać tylko bool, przechowujemy też komunikat dla mediatora.
/// </summary>
public class WynikWalidacji
{
    public bool CzyPoprawny { get; }
    public string Komunikat { get; }

    private WynikWalidacji(bool czyPoprawny, string komunikat)
    {
        CzyPoprawny = czyPoprawny;
        Komunikat = komunikat;
    }

    public static WynikWalidacji Sukces(string komunikat)
    {
        return new WynikWalidacji(true, komunikat);
    }

    public static WynikWalidacji Blad(string komunikat)
    {
        return new WynikWalidacji(false, komunikat);
    }
}
