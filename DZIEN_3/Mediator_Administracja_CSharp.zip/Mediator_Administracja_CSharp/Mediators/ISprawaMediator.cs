using MediatorAdministracja.Models;

namespace MediatorAdministracja.Mediators;

/// <summary>
/// Interfejs mediatora.
/// Określa zdarzenia/procesy, które mogą zostać zgłoszone przez aplikację.
/// </summary>
public interface ISprawaMediator
{
    void ZlozWniosek(Wniosek wniosek);
    void WniosekZarejestrowany(Wniosek wniosek);
    void WniosekOdrzucony(Wniosek wniosek, string powod);
    void DecyzjaWygenerowana(Wniosek wniosek);
}
