using MediatorAdministracja.Components;
using MediatorAdministracja.Models;

namespace MediatorAdministracja.Mediators;

/// <summary>
/// Concrete Mediator.
/// Koordynuje komunikację między komponentami systemu administracyjnego.
/// Dzięki temu komponenty nie wywołują się bezpośrednio.
/// </summary>
public class SprawaMediator : ISprawaMediator
{
    private readonly WalidatorWniosku _walidator;
    private readonly RejestrSpraw _rejestr;
    private readonly GeneratorDecyzji _generatorDecyzji;
    private readonly Archiwum _archiwum;
    private readonly Powiadomienia _powiadomienia;
    private readonly HistoriaOperacji _historia;

    public SprawaMediator(
        WalidatorWniosku walidator,
        RejestrSpraw rejestr,
        GeneratorDecyzji generatorDecyzji,
        Archiwum archiwum,
        Powiadomienia powiadomienia,
        HistoriaOperacji historia)
    {
        _walidator = walidator;
        _rejestr = rejestr;
        _generatorDecyzji = generatorDecyzji;
        _archiwum = archiwum;
        _powiadomienia = powiadomienia;
        _historia = historia;
    }

    public void ZlozWniosek(Wniosek wniosek)
    {
        Console.WriteLine("====================================================");
        Console.WriteLine($"MEDIATOR: przyjęto wniosek do obsługi: {wniosek}");
        Console.WriteLine("====================================================");

        _historia.Dodaj($"Przyjęto wniosek #{wniosek.Id} do procesu.");

        WynikWalidacji wynik = _walidator.Sprawdz(wniosek);
        _historia.Dodaj($"Walidacja wniosku #{wniosek.Id}: {wynik.Komunikat}");

        if (!wynik.CzyPoprawny)
        {
            WniosekOdrzucony(wniosek, wynik.Komunikat);
            Console.WriteLine();
            return;
        }

        _rejestr.Zarejestruj(wniosek);
        _historia.Dodaj($"Zarejestrowano sprawę: {wniosek.NumerSprawy}.");

        _generatorDecyzji.Wygeneruj(wniosek);
        if (!string.IsNullOrWhiteSpace(wniosek.Decyzja))
        {
            DecyzjaWygenerowana(wniosek);
        }

        _archiwum.Zapisz(wniosek);
        _historia.Dodaj($"Zarchiwizowano sprawę #{wniosek.Id}.");

        WniosekZarejestrowany(wniosek);

        Console.WriteLine();
    }

    public void WniosekZarejestrowany(Wniosek wniosek)
    {
        _powiadomienia.Wyslij(
            wniosek.Obywatel,
            $"Wniosek został zarejestrowany. Numer sprawy: {wniosek.NumerSprawy}."
        );

        _historia.Dodaj($"Wysłano powiadomienie o rejestracji wniosku #{wniosek.Id}.");
    }

    public void WniosekOdrzucony(Wniosek wniosek, string powod)
    {
        wniosek.Status = "Odrzucony";

        _powiadomienia.Wyslij(
            wniosek.Obywatel,
            $"Wniosek #{wniosek.Id} został odrzucony. Powód: {powod}"
        );

        _archiwum.Zapisz(wniosek);
        _historia.Dodaj($"Odrzucono wniosek #{wniosek.Id}. Powód: {powod}");
    }

    public void DecyzjaWygenerowana(Wniosek wniosek)
    {
        Console.WriteLine($"Mediator: decyzja została wygenerowana dla sprawy {wniosek.NumerSprawy}.");
        _historia.Dodaj($"Wygenerowano decyzję dla sprawy {wniosek.NumerSprawy}.");
    }
}
