using MediatorAdministracja.Mediators;
using MediatorAdministracja.Models;

namespace MediatorAdministracja.Infrastructure;

/// <summary>
/// Prosta warstwa aplikacyjna.
/// Klient aplikacji zna mediatora, ale nie zna wszystkich komponentów procesu.
/// </summary>
public class SprawaApplication
{
    private readonly ISprawaMediator _mediator;

    public SprawaApplication(ISprawaMediator mediator)
    {
        _mediator = mediator;
    }

    public void Obsluz(Wniosek wniosek)
    {
        _mediator.ZlozWniosek(wniosek);
    }
}
