# Rozwiązanie: Mediator + Fasada w świecie Gry o Tron

Pełny projekt C# / .NET 8 pokazujący połączenie dwóch wzorców projektowych:

- **Fasada**: `KingdomFacade`
- **Mediator**: `SmallCouncilMediator`

## Co robi aplikacja?

Aplikacja symuluje Małą Radę Westeros, która rozpatruje prośby o sojusz między rodami.

Kod klienta korzysta z jednej prostej klasy:

```csharp
kingdom.RequestAlliance(stark, lannister, "wspólna obrona królestwa");
```

Klient nie musi wiedzieć, że wewnątrz działają:

- kruki,
- doradca wojskowy,
- doradca skarbu,
- archiwum rady,
- mistrz szeptów,
- doradca od smoków.

## Struktura katalogów

```text
Models/
  GreatHouse.cs
  AllianceRequest.cs

Components/
  RavenMessenger.cs
  ArmyAdvisor.cs
  TreasuryAdvisor.cs
  CouncilArchive.cs
  SpyMaster.cs
  DragonAdvisor.cs

Mediators/
  ICouncilMediator.cs
  SmallCouncilMediator.cs

Facade/
  KingdomFacade.cs

Docs/
  Omowienie_dydaktyczne.md
  Zadanie_dla_chetnych.md

Program.cs
```

## Uruchomienie

W Visual Studio otwórz:

```text
Rozwiazanie_Mediator_Fasada_GraOTron_CSharp.sln
```

Następnie uruchom przez `Ctrl + F5`.

Z terminala:

```bash
dotnet run
```

## Wariant dla chętnych

W projekcie zaimplementowano również wariant rozszerzony:

- `SpyMaster` analizuje ryzyko polityczne,
- `DragonAdvisor` analizuje przewagę strategiczną smoków,
- Mediator może przekazać sprawę do decyzji króla.
