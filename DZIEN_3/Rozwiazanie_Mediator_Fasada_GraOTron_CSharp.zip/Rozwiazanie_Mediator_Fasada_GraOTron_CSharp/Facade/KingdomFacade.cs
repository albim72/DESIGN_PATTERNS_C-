using RozwiazanieMediatorFasadaGraOTron.Mediators;
using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Facade;

/// <summary>
/// Fasada: proste wejście do procesu zawierania sojuszu.
/// Kod klienta nie musi znać kruków, doradców, archiwum ani szczegółów mediatora.
/// </summary>
public class KingdomFacade
{
    private readonly ICouncilMediator _mediator;

    public KingdomFacade(ICouncilMediator mediator)
    {
        _mediator = mediator;
    }

    public void RequestAlliance(
        GreatHouse fromHouse,
        GreatHouse toHouse,
        string purpose,
        bool requiresSecretCouncil = false)
    {
        Console.WriteLine("====================================================");
        Console.WriteLine("Fasada Królestwa: rozpoczęcie procesu sojuszu");
        Console.WriteLine($"Wniosek: {fromHouse.Name} prosi o sojusz z rodem {toHouse.Name}");
        Console.WriteLine("====================================================");

        AllianceRequest request = new AllianceRequest(
            fromHouse,
            toHouse,
            purpose,
            requiresSecretCouncil);

        _mediator.SubmitAllianceRequest(request);
    }
}
