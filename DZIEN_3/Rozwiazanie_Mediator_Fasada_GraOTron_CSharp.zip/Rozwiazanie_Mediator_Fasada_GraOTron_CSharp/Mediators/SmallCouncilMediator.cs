using RozwiazanieMediatorFasadaGraOTron.Components;
using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Mediators;

/// <summary>
/// Concrete Mediator: koordynuje naradę Małej Rady.
/// Komponenty nie wywołują się wzajemnie bezpośrednio. Mediator zarządza kolejnością procesu.
/// </summary>
public class SmallCouncilMediator : ICouncilMediator
{
    private readonly RavenMessenger _ravenMessenger;
    private readonly ArmyAdvisor _armyAdvisor;
    private readonly TreasuryAdvisor _treasuryAdvisor;
    private readonly CouncilArchive _archive;

    // Wariant dla chętnych.
    private readonly SpyMaster _spyMaster;
    private readonly DragonAdvisor _dragonAdvisor;

    public SmallCouncilMediator(
        RavenMessenger ravenMessenger,
        ArmyAdvisor armyAdvisor,
        TreasuryAdvisor treasuryAdvisor,
        CouncilArchive archive,
        SpyMaster spyMaster,
        DragonAdvisor dragonAdvisor)
    {
        _ravenMessenger = ravenMessenger;
        _armyAdvisor = armyAdvisor;
        _treasuryAdvisor = treasuryAdvisor;
        _archive = archive;
        _spyMaster = spyMaster;
        _dragonAdvisor = dragonAdvisor;
    }

    public void SubmitAllianceRequest(AllianceRequest request)
    {
        Console.WriteLine("Mała Rada: przyjęto prośbę o sojusz.");
        Console.WriteLine(request);
        Console.WriteLine();

        bool enoughArmy = _armyAdvisor.HasEnoughArmy(request.FromHouse);
        if (!enoughArmy)
        {
            AllianceRejected(request, "Ród ma zbyt małą armię, aby zawrzeć wiarygodny sojusz.");
            return;
        }

        bool enoughGold = _treasuryAdvisor.HasEnoughGold(request.FromHouse);
        if (!enoughGold)
        {
            AllianceRejected(request, "Ród ma za mało złota, aby utrzymać sojusz.");
            return;
        }

        // Wariant dla chętnych: analiza ryzyka politycznego.
        request.RiskLevel = _spyMaster.EvaluateRisk(request);
        Console.WriteLine($"Mistrz szeptów: poziom ryzyka = {request.RiskLevel}/100.");

        if (request.RiskLevel >= 70)
        {
            AllianceRejected(request, "Ryzyko zdrady lub politycznego chaosu jest zbyt wysokie.");
            return;
        }

        bool strategicAdvantage = _dragonAdvisor.GivesStrategicAdvantage(request);
        if (strategicAdvantage && request.RiskLevel >= 40)
        {
            AllianceRequiresRoyalDecision(
                request,
                "Sojusz ma przewagę strategiczną dzięki smokom, ale wymaga decyzji króla z powodu podwyższonego ryzyka.");
            return;
        }

        AllianceAccepted(request);
    }

    public void AllianceAccepted(AllianceRequest request)
    {
        request.Status = "Zaakceptowany";
        request.CouncilDecision = "Mała Rada zaakceptowała propozycję sojuszu.";

        _ravenMessenger.SendRaven(request.ToHouse, request.CouncilDecision);
        _ravenMessenger.SendRaven(request.FromHouse, "Wasza propozycja sojuszu została przyjęta przez Małą Radę.");
        _archive.Save(request);

        Console.WriteLine("Mała Rada: sojusz zaakceptowany.");
        Console.WriteLine();
    }

    public void AllianceRejected(AllianceRequest request, string reason)
    {
        request.Status = "Odrzucony";
        request.CouncilDecision = reason;

        _ravenMessenger.SendRaven(request.FromHouse, $"Sojusz odrzucony. Powód: {reason}");
        _archive.Save(request);

        Console.WriteLine("Mała Rada: sojusz odrzucony.");
        Console.WriteLine();
    }

    public void AllianceRequiresRoyalDecision(AllianceRequest request, string reason)
    {
        request.Status = "Wymaga decyzji króla";
        request.CouncilDecision = reason;

        _ravenMessenger.SendRaven(request.FromHouse, $"Sprawa sojuszu wymaga decyzji króla. Uzasadnienie: {reason}");
        _ravenMessenger.SendRaven(request.ToHouse, $"Propozycja sojuszu wymaga decyzji króla. Uzasadnienie: {reason}");
        _archive.Save(request);

        Console.WriteLine("Mała Rada: sprawa przekazana do decyzji króla.");
        Console.WriteLine();
    }
}
