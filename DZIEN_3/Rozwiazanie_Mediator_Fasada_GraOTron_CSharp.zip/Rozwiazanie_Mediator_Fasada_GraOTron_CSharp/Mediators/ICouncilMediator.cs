using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Mediators;

/// <summary>
/// Mediator: wspólny kontrakt Małej Rady.
/// Fasada korzysta z tego interfejsu, a nie bezpośrednio z komponentów.
/// </summary>
public interface ICouncilMediator
{
    void SubmitAllianceRequest(AllianceRequest request);
    void AllianceAccepted(AllianceRequest request);
    void AllianceRejected(AllianceRequest request, string reason);
    void AllianceRequiresRoyalDecision(AllianceRequest request, string reason);
}
