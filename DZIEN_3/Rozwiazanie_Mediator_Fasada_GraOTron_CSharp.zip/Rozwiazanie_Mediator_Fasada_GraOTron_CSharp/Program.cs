using RozwiazanieMediatorFasadaGraOTron.Components;
using RozwiazanieMediatorFasadaGraOTron.Facade;
using RozwiazanieMediatorFasadaGraOTron.Mediators;
using RozwiazanieMediatorFasadaGraOTron.Models;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.WriteLine("====================================================");
Console.WriteLine(" MEDIATOR + FASADA - MAŁA RADA WESTEROS");
Console.WriteLine("====================================================");
Console.WriteLine();

// 1. Komponenty systemu. Każdy robi jedną rzecz.
RavenMessenger ravenMessenger = new RavenMessenger();
ArmyAdvisor armyAdvisor = new ArmyAdvisor();
TreasuryAdvisor treasuryAdvisor = new TreasuryAdvisor();
CouncilArchive archive = new CouncilArchive();

// Wariant dla chętnych: dodatkowe komponenty, których Program.cs nie używa bezpośrednio.
SpyMaster spyMaster = new SpyMaster();
DragonAdvisor dragonAdvisor = new DragonAdvisor();

// 2. Mediator koordynuje komponenty.
ICouncilMediator mediator = new SmallCouncilMediator(
    ravenMessenger,
    armyAdvisor,
    treasuryAdvisor,
    archive,
    spyMaster,
    dragonAdvisor);

// 3. Fasada jest prostym punktem wejścia dla klienta.
KingdomFacade kingdom = new KingdomFacade(mediator);

// 4. Przykładowe rody.
GreatHouse stark = new GreatHouse(
    name: "Stark",
    seat: "Winterfell",
    armySize: 9000,
    gold: 1200,
    trustLevel: 85);

GreatHouse lannister = new GreatHouse(
    name: "Lannister",
    seat: "Casterly Rock",
    armySize: 12000,
    gold: 5000,
    trustLevel: 55);

GreatHouse greyjoy = new GreatHouse(
    name: "Greyjoy",
    seat: "Pyke",
    armySize: 3000,
    gold: 600,
    trustLevel: 35);

GreatHouse targaryen = new GreatHouse(
    name: "Targaryen",
    seat: "Dragonstone",
    armySize: 7000,
    gold: 1600,
    trustLevel: 62,
    hasDragons: true);

GreatHouse tyrell = new GreatHouse(
    name: "Tyrell",
    seat: "Highgarden",
    armySize: 8000,
    gold: 4200,
    trustLevel: 76);

// 5. Podstawowe rozwiązanie zadania.
kingdom.RequestAlliance(
    fromHouse: stark,
    toHouse: lannister,
    purpose: "wspólna obrona królestwa przed zagrożeniem z północy");

kingdom.RequestAlliance(
    fromHouse: greyjoy,
    toHouse: stark,
    purpose: "atak morski na wspólnego wroga");

// 6. Wariant dla chętnych: ryzyko polityczne oraz smoki.
kingdom.RequestAlliance(
    fromHouse: targaryen,
    toHouse: tyrell,
    purpose: "tajny sojusz strategiczny z użyciem smoków",
    requiresSecretCouncil: true);

kingdom.RequestAlliance(
    fromHouse: lannister,
    toHouse: tyrell,
    purpose: "wspólne finansowanie kampanii wojennej",
    requiresSecretCouncil: true);

// 7. Archiwum decyzji rady.
archive.PrintArchive();

Console.WriteLine("Koniec demonstracji.");
Console.WriteLine("W projekcie pokazano: Fasada = KingdomFacade, Mediator = SmallCouncilMediator.");
