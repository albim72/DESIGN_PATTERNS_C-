namespace RozwiazanieMediatorFasadaGraOTron.Models;

/// <summary>
/// Model prośby o sojusz między dwoma rodami.
/// Obiekt jest przekazywany do Mediatora przez Fasadę.
/// </summary>
public class AllianceRequest
{
    public GreatHouse FromHouse { get; }
    public GreatHouse ToHouse { get; }
    public string Purpose { get; }

    // Wariant dla chętnych: czy sprawa wymaga dodatkowej, tajnej analizy.
    public bool RequiresSecretCouncil { get; }

    public string Status { get; set; } = "Nowy";
    public string? CouncilDecision { get; set; }
    public int RiskLevel { get; set; }

    public AllianceRequest(
        GreatHouse fromHouse,
        GreatHouse toHouse,
        string purpose,
        bool requiresSecretCouncil = false)
    {
        FromHouse = fromHouse;
        ToHouse = toHouse;
        Purpose = purpose;
        RequiresSecretCouncil = requiresSecretCouncil;
    }

    public override string ToString()
    {
        string secret = RequiresSecretCouncil ? "tak" : "nie";
        return $"Sojusz: {FromHouse.Name} -> {ToHouse.Name}, cel: {Purpose}, tajna rada: {secret}, status: {Status}";
    }
}
