namespace RozwiazanieMediatorFasadaGraOTron.Models;

/// <summary>
/// Model rodu z Westeros.
/// Wersja finalna zawiera pola podstawowe oraz dwa pola z wariantu dla chętnych:
/// TrustLevel i HasDragons.
/// </summary>
public class GreatHouse
{
    public string Name { get; }
    public string Seat { get; }
    public int ArmySize { get; }
    public int Gold { get; }

    // Wariant dla chętnych: ocena wiarygodności rodu i obecność smoków.
    public int TrustLevel { get; }
    public bool HasDragons { get; }

    public GreatHouse(
        string name,
        string seat,
        int armySize,
        int gold,
        int trustLevel = 70,
        bool hasDragons = false)
    {
        Name = name;
        Seat = seat;
        ArmySize = armySize;
        Gold = gold;
        TrustLevel = trustLevel;
        HasDragons = hasDragons;
    }

    public override string ToString()
    {
        string dragons = HasDragons ? "tak" : "nie";
        return $"{Name} z siedzibą w {Seat} | armia: {ArmySize}, złoto: {Gold}, zaufanie: {TrustLevel}, smoki: {dragons}";
    }
}
