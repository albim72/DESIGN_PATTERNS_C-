using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Components;

/// <summary>
/// Wariant dla chętnych.
/// Komponent oceniający ryzyko zdrady albo politycznej niestabilności.
/// </summary>
public class SpyMaster
{
    public int EvaluateRisk(AllianceRequest request)
    {
        Console.WriteLine("Mistrz szeptów: analizuję ryzyko polityczne sojuszu...");

        int risk = 0;

        if (request.FromHouse.TrustLevel < 40)
        {
            risk += 50;
        }
        else if (request.FromHouse.TrustLevel < 70)
        {
            risk += 25;
        }

        if (request.RequiresSecretCouncil)
        {
            risk += 20;
        }

        if (request.Purpose.Contains("atak", StringComparison.OrdinalIgnoreCase))
        {
            risk += 15;
        }

        return Math.Min(risk, 100);
    }

    public string GetRiskReport(AllianceRequest request)
    {
        int risk = EvaluateRisk(request);
        return $"Ryzyko sojuszu oceniono na {risk}/100.";
    }
}
