using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Components;

/// <summary>
/// Komponent odpowiedzialny za wysyłanie kruków.
/// Nie zna mediatora, doradców ani archiwum.
/// </summary>
public class RavenMessenger
{
    public void SendRaven(GreatHouse targetHouse, string message)
    {
        Console.WriteLine($"Kruk wysłany do rodu {targetHouse.Name} ({targetHouse.Seat}): {message}");
    }
}
