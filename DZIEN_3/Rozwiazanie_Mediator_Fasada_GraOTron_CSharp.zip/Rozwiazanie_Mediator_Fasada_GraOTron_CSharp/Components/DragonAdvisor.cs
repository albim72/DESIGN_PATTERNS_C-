using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Components;

/// <summary>
/// Wariant dla chętnych.
/// Doradca strategiczny ocenia, czy obecność smoków zmienia wagę sojuszu.
/// </summary>
public class DragonAdvisor
{
    public bool GivesStrategicAdvantage(AllianceRequest request)
    {
        Console.WriteLine("Doradca od smoków: sprawdzam przewagę strategiczną...");
        return request.FromHouse.HasDragons || request.ToHouse.HasDragons;
    }

    public string GetDragonReport(AllianceRequest request)
    {
        if (GivesStrategicAdvantage(request))
        {
            return "Obecność smoków daje sojuszowi przewagę strategiczną.";
        }

        return "Brak smoków. Sojusz oceniany wyłącznie na podstawie armii, złota i ryzyka politycznego.";
    }
}
