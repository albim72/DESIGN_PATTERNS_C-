using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Components;

/// <summary>
/// Komponent oceniający siłę militarną rodu proszącego o sojusz.
/// </summary>
public class ArmyAdvisor
{
    private const int MinimumArmySize = 5000;

    public bool HasEnoughArmy(GreatHouse house)
    {
        Console.WriteLine($"Doradca wojskowy: oceniam armię rodu {house.Name}. Armia: {house.ArmySize}.");
        return house.ArmySize >= MinimumArmySize;
    }

    public string GetArmyReport(GreatHouse house)
    {
        if (HasEnoughArmy(house))
        {
            return $"Ród {house.Name} ma wystarczającą armię do sojuszu.";
        }

        return $"Ród {house.Name} ma zbyt małą armię. Minimum: {MinimumArmySize}.";
    }
}
