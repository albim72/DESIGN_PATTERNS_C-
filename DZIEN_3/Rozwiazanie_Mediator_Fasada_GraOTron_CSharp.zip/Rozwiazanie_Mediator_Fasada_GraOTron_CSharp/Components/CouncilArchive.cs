using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Components;

/// <summary>
/// Komponent archiwum Małej Rady.
/// Zapisuje decyzje i umożliwia wypisanie historii obrad.
/// </summary>
public class CouncilArchive
{
    private readonly List<string> _entries = new();

    public void Save(AllianceRequest request)
    {
        string entry = $"{DateTime.Now:HH:mm:ss} | {request.FromHouse.Name} -> {request.ToHouse.Name} | status: {request.Status} | decyzja: {request.CouncilDecision}";
        _entries.Add(entry);
        Console.WriteLine($"Archiwum Małej Rady: zapisano sprawę sojuszu {request.FromHouse.Name} -> {request.ToHouse.Name}.");
    }

    public void PrintArchive()
    {
        Console.WriteLine("\n================ ARCHIWUM MAŁEJ RADY ================");

        if (_entries.Count == 0)
        {
            Console.WriteLine("Brak wpisów w archiwum.");
        }
        else
        {
            foreach (string entry in _entries)
            {
                Console.WriteLine(entry);
            }
        }

        Console.WriteLine("======================================================\n");
    }
}
