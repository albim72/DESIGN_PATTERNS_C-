using RozwiazanieMediatorFasadaGraOTron.Models;

namespace RozwiazanieMediatorFasadaGraOTron.Components;

/// <summary>
/// Komponent oceniający zasoby finansowe rodu.
/// </summary>
public class TreasuryAdvisor
{
    private const int MinimumGold = 1000;

    public bool HasEnoughGold(GreatHouse house)
    {
        Console.WriteLine($"Doradca skarbu: oceniam złoto rodu {house.Name}. Złoto: {house.Gold}.");
        return house.Gold >= MinimumGold;
    }

    public string GetTreasuryReport(GreatHouse house)
    {
        if (HasEnoughGold(house))
        {
            return $"Ród {house.Name} ma wystarczające zasoby finansowe.";
        }

        return $"Ród {house.Name} ma za mało złota. Minimum: {MinimumGold}.";
    }
}
