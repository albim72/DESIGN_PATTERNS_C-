# Zadanie dla chętnych: rozbudowa Małej Rady

W tej finalnej wersji zadanie dla chętnych zostało już zaimplementowane, ale możesz poprosić kursantów, aby wykonali je samodzielnie na bazie szkieletu.

## Cel

Rozbuduj system sojuszy o dodatkowy poziom analizy politycznej.

## Wymagania

1. Dodaj komponent `SpyMaster`, który ocenia ryzyko polityczne sojuszu.
2. Dodaj komponent `DragonAdvisor`, który sprawdza, czy któryś ród posiada smoki.
3. Rozszerz `GreatHouse` o pola:
   - `TrustLevel`,
   - `HasDragons`.
4. Rozszerz `AllianceRequest` o pole:
   - `RequiresSecretCouncil`.
5. W Mediatorze dodaj reguły:
   - jeśli ryzyko jest bardzo wysokie, sojusz zostaje odrzucony,
   - jeśli są smoki i ryzyko jest podwyższone, sprawa wymaga decyzji króla,
   - jeśli warunki są dobre, sojusz zostaje zaakceptowany.
6. `Program.cs` nadal powinien korzystać tylko z `KingdomFacade`.

## Pytania

1. Czy po dodaniu `SpyMaster` musieliśmy zmienić `KingdomFacade`?
2. Czy po dodaniu `DragonAdvisor` musieliśmy zmienić komponent `RavenMessenger`?
3. Dlaczego nową logikę koordynacji umieszczamy w Mediatorze?
4. Co grozi, jeśli Mediator zacznie zawierać zbyt dużo logiki biznesowej?
