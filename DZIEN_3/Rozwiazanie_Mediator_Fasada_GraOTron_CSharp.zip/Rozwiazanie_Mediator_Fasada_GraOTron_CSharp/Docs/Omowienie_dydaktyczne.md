# Omówienie dydaktyczne: Mediator + Fasada, świat Gry o Tron

## Co robi program?

Program symuluje pracę Małej Rady, która rozpatruje prośby o sojusz między rodami Westeros.

Kod klienta korzysta tylko z klasy `KingdomFacade`. Fasada tworzy obiekt `AllianceRequest` i przekazuje go do `SmallCouncilMediator`.

`SmallCouncilMediator` koordynuje komponenty:

- `RavenMessenger`,
- `ArmyAdvisor`,
- `TreasuryAdvisor`,
- `CouncilArchive`,
- `SpyMaster`,
- `DragonAdvisor`.

Komponenty nie znają siebie nawzajem. Mediator decyduje, kiedy który komponent ma zostać uruchomiony.

## Co jest Fasadą?

`KingdomFacade`.

Fasada ukrywa złożoność procesu. Program nie musi znać doradców, kruków, archiwum ani szczegółów Małej Rady.

## Co jest Mediatorem?

`SmallCouncilMediator`.

Mediator koordynuje komunikację między komponentami i podejmuje decyzję o przyjęciu, odrzuceniu albo przekazaniu sojuszu do decyzji króla.

## Kolejność omawiania plików

1. `Models/GreatHouse.cs`
2. `Models/AllianceRequest.cs`
3. `Components/RavenMessenger.cs`
4. `Components/ArmyAdvisor.cs`
5. `Components/TreasuryAdvisor.cs`
6. `Components/CouncilArchive.cs`
7. `Components/SpyMaster.cs`
8. `Components/DragonAdvisor.cs`
9. `Mediators/ICouncilMediator.cs`
10. `Mediators/SmallCouncilMediator.cs`
11. `Facade/KingdomFacade.cs`
12. `Program.cs`

## Zadanie podstawowe, które zostało rozwiązane

- Utworzono model rodu `GreatHouse`.
- Utworzono model prośby o sojusz `AllianceRequest`.
- Utworzono komponenty Małej Rady.
- Utworzono Mediatora `SmallCouncilMediator`.
- Utworzono Fasadę `KingdomFacade`.
- Program pokazuje zaakceptowany i odrzucony sojusz.

## Wariant dla chętnych, który też został zaimplementowany

Dodano:

- `SpyMaster`, który ocenia ryzyko polityczne,
- `DragonAdvisor`, który sprawdza przewagę strategiczną smoków,
- pole `TrustLevel` w `GreatHouse`,
- pole `HasDragons` w `GreatHouse`,
- pole `RequiresSecretCouncil` w `AllianceRequest`,
- status `Wymaga decyzji króla`.

## Pytania kontrolne

1. Która klasa pełni rolę Fasady?
2. Która klasa pełni rolę Mediatora?
3. Dlaczego `Program.cs` nie korzysta bezpośrednio z `RavenMessenger`?
4. Dlaczego `ArmyAdvisor` nie zna `TreasuryAdvisor`?
5. Co trzeba zmienić, aby dodać nowy komponent Małej Rady?
6. Czym różni się Mediator od Fasady?
