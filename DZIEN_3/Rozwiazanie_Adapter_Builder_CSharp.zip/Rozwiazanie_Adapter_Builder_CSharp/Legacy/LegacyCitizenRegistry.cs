namespace Rozwiazanie_Adapter_Builder_CSharp.Legacy;

public class LegacyCitizenRegistry
{
    private readonly Dictionary<string, string> _citizens = new()
    {
        { "44051401359", "44051401359;Jan Kowalski;Lublin" },
        { "12345678901", "12345678901;Anna Nowak;Warszawa" }
    };

    // Stary, niewygodny interfejs: system zwraca jeden tekst rozdzielony średnikami.
    public string GetCitizenData(string pesel)
    {
        if (!_citizens.TryGetValue(pesel, out string? data))
        {
            throw new KeyNotFoundException($"Nie znaleziono obywatela o numerze PESEL: {pesel}");
        }

        return data;
    }
}
