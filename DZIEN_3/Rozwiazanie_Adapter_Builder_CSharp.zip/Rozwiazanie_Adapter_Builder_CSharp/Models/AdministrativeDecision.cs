namespace Rozwiazanie_Adapter_Builder_CSharp.Models;

public class AdministrativeDecision
{
    public string DecisionNumber { get; set; } = string.Empty;
    public Citizen? Citizen { get; set; }
    public string CaseType { get; set; } = string.Empty;
    public string LegalBasis { get; set; } = string.Empty;
    public string Justification { get; set; } = string.Empty;
    public string Result { get; set; } = string.Empty;
    public string Instruction { get; set; } = string.Empty;
    public DateTime IssueDate { get; set; } = DateTime.Today;

    public void Print()
    {
        Console.WriteLine("DECYZJA ADMINISTRACYJNA");
        Console.WriteLine($"Numer decyzji: {DecisionNumber}");
        Console.WriteLine($"Data wydania: {IssueDate:yyyy-MM-dd}");
        Console.WriteLine();

        Console.WriteLine("Obywatel:");
        Console.WriteLine($"PESEL: {Citizen?.Pesel}");
        Console.WriteLine($"Imię i nazwisko: {Citizen?.FullName}");
        Console.WriteLine($"Miasto: {Citizen?.City}");
        Console.WriteLine();

        Console.WriteLine("Typ sprawy:");
        Console.WriteLine(CaseType);
        Console.WriteLine();

        Console.WriteLine("Podstawa prawna:");
        Console.WriteLine(LegalBasis);
        Console.WriteLine();

        Console.WriteLine("Uzasadnienie:");
        Console.WriteLine(Justification);
        Console.WriteLine();

        Console.WriteLine("Rozstrzygnięcie:");
        Console.WriteLine(Result);
        Console.WriteLine();

        Console.WriteLine("Pouczenie:");
        Console.WriteLine(Instruction);
        Console.WriteLine(new string('-', 60));
    }
}
