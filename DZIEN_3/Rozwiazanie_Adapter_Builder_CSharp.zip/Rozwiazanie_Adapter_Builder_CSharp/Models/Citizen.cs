namespace Rozwiazanie_Adapter_Builder_CSharp.Models;

public class Citizen
{
    public string Pesel { get; }
    public string FullName { get; }
    public string City { get; }

    public Citizen(string pesel, string fullName, string city)
    {
        Pesel = pesel;
        FullName = fullName;
        City = city;
    }
}
