# Pytania kontrolne – odpowiedzi

## 1. Która klasa pełni rolę Adaptera?

Rolę Adaptera pełni klasa `CitizenRegistryAdapter`.

## 2. Jaki problem rozwiązuje Adapter w tym zadaniu?

Adapter rozwiązuje problem niezgodności interfejsów. Stary system `LegacyCitizenRegistry` zwraca dane obywatela jako jeden tekst w formacie `PESEL;Imię i nazwisko;Miasto`, a nowa aplikacja oczekuje obiektu `Citizen`. Adapter tłumaczy więc stary format na nowy model obiektowy.

## 3. Która klasa pełni rolę Buildera?

Rolę Buildera pełni klasa `AdministrativeDecisionBuilder`.

## 4. Dlaczego Builder jest lepszy niż konstruktor z wieloma parametrami?

Builder jest czytelniejszy, ponieważ pozwala tworzyć obiekt krok po kroku metodami o jasnych nazwach. Unikamy ogromnego konstruktora, w którym łatwo pomylić kolejność argumentów. Builder dobrze nadaje się do obiektów z wieloma polami, szczególnie gdy część pól może być opcjonalna albo zależna od typu decyzji.

## 5. Co trzeba zmienić, jeśli stary system zacznie zwracać dane w innym formacie, np. JSON?

Wystarczy zmienić logikę parsowania w klasie `CitizenRegistryAdapter`. Reszta aplikacji nadal będzie korzystała z interfejsu `ICitizenProvider` i metody `GetCitizen`, więc nie trzeba zmieniać kodu budowania decyzji ani klasy `AdministrativeDecision`.

## 6. Czy klasa AdministrativeDecision powinna znać LegacyCitizenRegistry? Dlaczego?

Nie. Klasa `AdministrativeDecision` powinna reprezentować decyzję administracyjną, a nie wiedzieć, skąd pochodzą dane obywatela. Gdyby znała `LegacyCitizenRegistry`, złamałaby zasadę pojedynczej odpowiedzialności i silnie związałaby model decyzji ze starym systemem.

## 7. Który wzorzec jest kreacyjny, a który strukturalny?

`Builder` jest wzorcem kreacyjnym, ponieważ odpowiada za tworzenie złożonego obiektu. `Adapter` jest wzorcem strukturalnym, ponieważ dopasowuje niezgodny interfejs starego systemu do oczekiwań nowej aplikacji.
