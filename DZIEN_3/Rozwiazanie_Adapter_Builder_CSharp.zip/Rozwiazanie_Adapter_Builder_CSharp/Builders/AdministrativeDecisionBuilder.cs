using Rozwiazanie_Adapter_Builder_CSharp.Models;

namespace Rozwiazanie_Adapter_Builder_CSharp.Builders;

public class AdministrativeDecisionBuilder
{
    private readonly AdministrativeDecision _decision = new();

    public AdministrativeDecisionBuilder WithDecisionNumber(string decisionNumber)
    {
        _decision.DecisionNumber = decisionNumber;
        return this;
    }

    public AdministrativeDecisionBuilder ForCitizen(Citizen citizen)
    {
        _decision.Citizen = citizen;
        return this;
    }

    public AdministrativeDecisionBuilder WithCaseType(string caseType)
    {
        _decision.CaseType = caseType;
        return this;
    }

    public AdministrativeDecisionBuilder WithLegalBasis(string legalBasis)
    {
        _decision.LegalBasis = legalBasis;
        return this;
    }

    public AdministrativeDecisionBuilder WithJustification(string justification)
    {
        _decision.Justification = justification;
        return this;
    }

    public AdministrativeDecisionBuilder WithResult(string result)
    {
        _decision.Result = result;
        return this;
    }

    public AdministrativeDecisionBuilder WithInstruction(string instruction)
    {
        _decision.Instruction = instruction;
        return this;
    }

    public AdministrativeDecisionBuilder IssuedOn(DateTime issueDate)
    {
        _decision.IssueDate = issueDate;
        return this;
    }

    public AdministrativeDecision Build()
    {
        Validate();
        return _decision;
    }

    private void Validate()
    {
        if (string.IsNullOrWhiteSpace(_decision.DecisionNumber))
            throw new InvalidOperationException("Brak numeru decyzji.");

        if (_decision.Citizen is null)
            throw new InvalidOperationException("Brak danych obywatela.");

        if (string.IsNullOrWhiteSpace(_decision.CaseType))
            throw new InvalidOperationException("Brak typu sprawy.");

        if (string.IsNullOrWhiteSpace(_decision.LegalBasis))
            throw new InvalidOperationException("Brak podstawy prawnej.");

        if (string.IsNullOrWhiteSpace(_decision.Result))
            throw new InvalidOperationException("Brak rozstrzygnięcia.");
    }
}
