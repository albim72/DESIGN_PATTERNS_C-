# Rozwiązanie zadania: Builder + Adapter w C#

Projekt pokazuje połączenie dwóch wzorców projektowych:

- **Adapter** – `CitizenRegistryAdapter` dopasowuje stary system `LegacyCitizenRegistry` do nowego interfejsu `ICitizenProvider`.
- **Builder** – `AdministrativeDecisionBuilder` buduje obiekt `AdministrativeDecision` krok po kroku.

## Struktura projektu

```text
Rozwiazanie_Adapter_Builder_CSharp/
├── Adapters/
│   └── CitizenRegistryAdapter.cs
├── Builders/
│   └── AdministrativeDecisionBuilder.cs
├── Interfaces/
│   └── ICitizenProvider.cs
├── Legacy/
│   └── LegacyCitizenRegistry.cs
├── Models/
│   ├── AdministrativeDecision.cs
│   └── Citizen.cs
├── Program.cs
├── Pytania_kontrolne.md
└── Rozwiazanie_Adapter_Builder_CSharp.csproj
```

## Uruchomienie

W katalogu projektu uruchom:

```bash
dotnet run
```

Program generuje dwie decyzje administracyjne:

1. Decyzję pozytywną.
2. Decyzję odmowną jako wariant dodatkowy.
