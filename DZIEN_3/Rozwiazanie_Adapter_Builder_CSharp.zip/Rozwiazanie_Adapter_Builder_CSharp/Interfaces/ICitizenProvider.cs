using Rozwiazanie_Adapter_Builder_CSharp.Models;

namespace Rozwiazanie_Adapter_Builder_CSharp.Interfaces;

public interface ICitizenProvider
{
    Citizen GetCitizen(string pesel);
}
