using Rozwiazanie_Adapter_Builder_CSharp.Adapters;
using Rozwiazanie_Adapter_Builder_CSharp.Builders;
using Rozwiazanie_Adapter_Builder_CSharp.Interfaces;
using Rozwiazanie_Adapter_Builder_CSharp.Legacy;
using Rozwiazanie_Adapter_Builder_CSharp.Models;

LegacyCitizenRegistry legacyRegistry = new LegacyCitizenRegistry();
ICitizenProvider citizenProvider = new CitizenRegistryAdapter(legacyRegistry);

// Decyzja pozytywna
Citizen janKowalski = citizenProvider.GetCitizen("44051401359");

AdministrativeDecision positiveDecision = new AdministrativeDecisionBuilder()
    .WithDecisionNumber("DEC/2026/001")
    .ForCitizen(janKowalski)
    .WithCaseType("Świadczenie emerytalne")
    .WithLegalBasis("Ustawa o systemie ubezpieczeń społecznych")
    .WithJustification("Obywatel spełnia wymagania formalne.")
    .WithResult("Przyznaje się świadczenie.")
    .WithInstruction("Od decyzji przysługuje odwołanie w terminie 14 dni.")
    .IssuedOn(new DateTime(2026, 6, 16))
    .Build();

positiveDecision.Print();

// Wariant dodatkowy: decyzja odmowna dla drugiego obywatela
Citizen annaNowak = citizenProvider.GetCitizen("12345678901");

AdministrativeDecision negativeDecision = new AdministrativeDecisionBuilder()
    .WithDecisionNumber("DEC/2026/002")
    .ForCitizen(annaNowak)
    .WithCaseType("Dodatek mieszkaniowy")
    .WithLegalBasis("Ustawa o dodatkach mieszkaniowych")
    .WithJustification("Obywatelka nie spełnia jednego z wymaganych kryteriów formalnych.")
    .WithResult("Odmawia się przyznania świadczenia.")
    .WithInstruction("Od decyzji przysługuje odwołanie w terminie 14 dni od dnia doręczenia decyzji.")
    .IssuedOn(new DateTime(2026, 6, 16))
    .Build();

negativeDecision.Print();
