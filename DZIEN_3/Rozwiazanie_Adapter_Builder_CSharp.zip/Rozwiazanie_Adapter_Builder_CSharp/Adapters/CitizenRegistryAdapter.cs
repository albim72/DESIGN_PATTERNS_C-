using Rozwiazanie_Adapter_Builder_CSharp.Interfaces;
using Rozwiazanie_Adapter_Builder_CSharp.Legacy;
using Rozwiazanie_Adapter_Builder_CSharp.Models;

namespace Rozwiazanie_Adapter_Builder_CSharp.Adapters;

public class CitizenRegistryAdapter : ICitizenProvider
{
    private readonly LegacyCitizenRegistry _legacyRegistry;

    public CitizenRegistryAdapter(LegacyCitizenRegistry legacyRegistry)
    {
        _legacyRegistry = legacyRegistry;
    }

    public Citizen GetCitizen(string pesel)
    {
        string rawData = _legacyRegistry.GetCitizenData(pesel);
        string[] parts = rawData.Split(';');

        if (parts.Length != 3)
        {
            throw new FormatException("Nieprawidłowy format danych obywatela w starym systemie.");
        }

        return new Citizen(
            pesel: parts[0],
            fullName: parts[1],
            city: parts[2]
        );
    }
}
