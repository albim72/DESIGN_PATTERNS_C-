using SzkieletMediatorFasadaGraOTron.Models;

namespace SzkieletMediatorFasadaGraOTron.Components;

/// <summary>
/// Komponent oceniający, czy ród ma wystarczającą siłę militarną do sojuszu.
/// </summary>
public class ArmyAdvisor
{
    public bool HasEnoughArmy(GreatHouse house)
    {
        // TODO dla kursanta:
        // Zwróć true, jeżeli armia rodu ma co najmniej 5000 żołnierzy.
        // Podpowiedź: użyj house.ArmySize.
        return house.ArmySize >= 5000;
    }
}
