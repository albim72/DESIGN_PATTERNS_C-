using SzkieletMediatorFasadaGraOTron.Models;

namespace SzkieletMediatorFasadaGraOTron.Components;

/// <summary>
/// Komponent archiwum Małej Rady.
/// Zapisuje wynik narady w konsoli.
/// </summary>
public class CouncilArchive
{
    public void Save(AllianceRequest request)
    {
        // TODO dla kursanta:
        // Wypisz status i decyzję rady dla danego wniosku o sojusz.
        Console.WriteLine($"[TODO] Archiwum rady: {request}");
    }
}
