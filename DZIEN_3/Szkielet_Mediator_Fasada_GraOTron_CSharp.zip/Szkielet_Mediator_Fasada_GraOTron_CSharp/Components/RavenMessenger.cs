using SzkieletMediatorFasadaGraOTron.Models;

namespace SzkieletMediatorFasadaGraOTron.Components;

/// <summary>
/// Komponent odpowiedzialny za wysyłanie kruków.
/// Nie zna innych komponentów. Nie zna Fasady. Nie zna szczegółów procesu.
/// </summary>
public class RavenMessenger
{
    public void SendRaven(GreatHouse targetHouse, string message)
    {
        // TODO dla kursanta:
        // Wypisz w konsoli informację o wysłaniu kruka do wskazanego rodu.
        Console.WriteLine($"[TODO] Kruk do {targetHouse.Name}: {message}");
    }
}
