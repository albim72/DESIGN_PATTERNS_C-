using SzkieletMediatorFasadaGraOTron.Models;

namespace SzkieletMediatorFasadaGraOTron.Components;

/// <summary>
/// Komponent oceniający, czy ród ma wystarczające zasoby finansowe.
/// </summary>
public class TreasuryAdvisor
{
    public bool HasEnoughGold(GreatHouse house)
    {
        // TODO dla kursanta:
        // Zwróć true, jeżeli ród ma co najmniej 1000 jednostek złota.
        // Podpowiedź: użyj house.Gold.
        return house.Gold >= 1000;
    }
}
