namespace SzkieletMediatorFasadaGraOTron.Models;

/// <summary>
/// Model prośby o sojusz między dwoma rodami.
/// Obiekt ten będzie przekazywany do Mediatora przez Fasadę.
/// </summary>
public class AllianceRequest
{
    public GreatHouse FromHouse { get; }
    public GreatHouse ToHouse { get; }
    public string Purpose { get; }

    public string Status { get; set; } = "Nowy";
    public string? CouncilDecision { get; set; }

    public AllianceRequest(GreatHouse fromHouse, GreatHouse toHouse, string purpose)
    {
        FromHouse = fromHouse;
        ToHouse = toHouse;
        Purpose = purpose;
    }

    public override string ToString()
    {
        return $"Sojusz: {FromHouse.Name} -> {ToHouse.Name}, cel: {Purpose}, status: {Status}";
    }
}
