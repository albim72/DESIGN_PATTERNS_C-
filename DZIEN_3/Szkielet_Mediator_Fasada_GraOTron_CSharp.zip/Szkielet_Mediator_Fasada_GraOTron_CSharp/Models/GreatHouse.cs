namespace SzkieletMediatorFasadaGraOTron.Models;

/// <summary>
/// Model rodu z Westeros.
/// Kursant może rozszerzyć klasę o Motto, LordName albo LoyaltyLevel.
/// </summary>
public class GreatHouse
{
    public string Name { get; }
    public string Seat { get; }
    public int ArmySize { get; }
    public int Gold { get; }

    public GreatHouse(string name, string seat, int armySize, int gold)
    {
        Name = name;
        Seat = seat;
        ArmySize = armySize;
        Gold = gold;
    }

    public override string ToString()
    {
        return $"{Name} z siedzibą w {Seat} | armia: {ArmySize}, złoto: {Gold}";
    }
}
