using SzkieletMediatorFasadaGraOTron.Components;
using SzkieletMediatorFasadaGraOTron.Facade;
using SzkieletMediatorFasadaGraOTron.Mediators;
using SzkieletMediatorFasadaGraOTron.Models;

Console.OutputEncoding = System.Text.Encoding.UTF8;

// ====================================================
// ZADANIE: Mediator + Fasada w świecie Gry o Tron
// ====================================================

// 1. Komponenty systemu
RavenMessenger ravenMessenger = new RavenMessenger();
ArmyAdvisor armyAdvisor = new ArmyAdvisor();
TreasuryAdvisor treasuryAdvisor = new TreasuryAdvisor();
CouncilArchive archive = new CouncilArchive();

// 2. Mediator, który koordynuje komponenty
ICouncilMediator mediator = new SmallCouncilMediator(
    ravenMessenger,
    armyAdvisor,
    treasuryAdvisor,
    archive);

// 3. Fasada, czyli proste wejście dla klienta
KingdomFacade kingdom = new KingdomFacade(mediator);

// 4. Przykładowe rody
GreatHouse stark = new GreatHouse("Stark", "Winterfell", armySize: 9000, gold: 1200);
GreatHouse lannister = new GreatHouse("Lannister", "Casterly Rock", armySize: 12000, gold: 5000);
GreatHouse greyjoy = new GreatHouse("Greyjoy", "Pyke", armySize: 3000, gold: 600);

// 5. Przykładowe użycie Fasady
kingdom.RequestAlliance(
    fromHouse: stark,
    toHouse: lannister,
    purpose: "wspólna obrona królestwa przed zagrożeniem z północy");

kingdom.RequestAlliance(
    fromHouse: greyjoy,
    toHouse: stark,
    purpose: "atak morski na wspólnego wroga");

Console.WriteLine("Koniec demonstracji. Uzupełnij miejsca TODO i rozbuduj projekt według treści zadania.");
