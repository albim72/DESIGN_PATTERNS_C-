# Instrukcja dla kursanta

## Cel

Uzupełnij projekt tak, aby pokazać współpracę wzorców **Mediator** i **Fasada**.

## Historia

Mała Rada Westeros rozpatruje prośby o sojusz między rodami. 
Kod klienta nie powinien znać wszystkich szczegółów narady. Ma korzystać z jednej prostej klasy: `KingdomFacade`.

## Wymagania

1. `KingdomFacade` ma być prostym punktem wejścia.
2. `SmallCouncilMediator` ma koordynować komponenty:
   - `RavenMessenger`,
   - `ArmyAdvisor`,
   - `TreasuryAdvisor`,
   - `CouncilArchive`.
3. Jeśli ród ma za małą armię lub za mało złota, sojusz ma zostać odrzucony.
4. Jeśli ród spełnia warunki, sojusz ma zostać zaakceptowany.
5. Program powinien wypisać proces w konsoli.

## Pytania kontrolne

1. Która klasa pełni rolę Mediatora?
2. Która klasa pełni rolę Fasady?
3. Dlaczego `Program.cs` nie powinien bezpośrednio korzystać z `RavenMessenger`?
4. Czym różni się Mediator od Fasady?
5. Jak dodać nowy komponent, np. `SpyMaster`, bez zmiany kodu klienta?
