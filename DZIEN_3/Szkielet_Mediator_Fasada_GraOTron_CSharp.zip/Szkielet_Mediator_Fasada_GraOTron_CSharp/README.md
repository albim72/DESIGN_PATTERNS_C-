# Szkielet projektu: Mediator + Fasada w świecie Gry o Tron

Projekt jest szkieletem do zadania indywidualnego dla kursantów C#.
Celem jest połączenie dwóch wzorców:

- **Mediator**: `SmallCouncilMediator` koordynuje komunikację między komponentami Małej Rady.
- **Fasada**: `KingdomFacade` daje prosty punkt wejścia do całego procesu zawierania sojuszu.

## Uruchomienie

W Visual Studio otwórz plik:

```text
Szkielet_Mediator_Fasada_GraOTron_CSharp.sln
```

Następnie uruchom projekt przez `Ctrl + F5`.

Z terminala:

```bash
dotnet run
```

## Kolejność pracy dla kursanta

1. Otwórz `Models/GreatHouse.cs` i `Models/AllianceRequest.cs`.
2. Zobacz komponenty w katalogu `Components`.
3. Przejdź do `Mediators/ICouncilMediator.cs`.
4. Uzupełnij lub przeanalizuj `Mediators/SmallCouncilMediator.cs`.
5. Uzupełnij lub przeanalizuj `Facade/KingdomFacade.cs`.
6. Sprawdź `Program.cs` i dodaj własne przykłady rodów.

## Co ma pokazać projekt?

Kod klienta w `Program.cs` nie powinien samodzielnie wywoływać kruków, doradców i archiwum.
Powinien korzystać z Fasady:

```csharp
kingdom.RequestAlliance(stark, lannister, "wspólna obrona królestwa");
```

Fasada tworzy wniosek o sojusz i przekazuje go do Mediatora.
Mediator koordynuje komponenty.

## Najważniejsza puenta

Fasada upraszcza wejście do systemu.
Mediator porządkuje komunikację wewnątrz systemu.
