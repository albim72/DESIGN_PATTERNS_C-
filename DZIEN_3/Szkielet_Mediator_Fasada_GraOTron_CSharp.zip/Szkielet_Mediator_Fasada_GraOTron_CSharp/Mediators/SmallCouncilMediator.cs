using SzkieletMediatorFasadaGraOTron.Components;
using SzkieletMediatorFasadaGraOTron.Models;

namespace SzkieletMediatorFasadaGraOTron.Mediators;

/// <summary>
/// Concrete Mediator: koordynuje naradę Małej Rady.
/// To tutaj komponenty współpracują, ale nie wywołują się wzajemnie bezpośrednio.
/// </summary>
public class SmallCouncilMediator : ICouncilMediator
{
    private readonly RavenMessenger _ravenMessenger;
    private readonly ArmyAdvisor _armyAdvisor;
    private readonly TreasuryAdvisor _treasuryAdvisor;
    private readonly CouncilArchive _archive;

    public SmallCouncilMediator(
        RavenMessenger ravenMessenger,
        ArmyAdvisor armyAdvisor,
        TreasuryAdvisor treasuryAdvisor,
        CouncilArchive archive)
    {
        _ravenMessenger = ravenMessenger;
        _armyAdvisor = armyAdvisor;
        _treasuryAdvisor = treasuryAdvisor;
        _archive = archive;
    }

    public void SubmitAllianceRequest(AllianceRequest request)
    {
        Console.WriteLine("Mała Rada: przyjęto prośbę o sojusz.");
        Console.WriteLine(request);

        // TODO dla kursanta:
        // 1. Użyj ArmyAdvisor, aby sprawdzić armię rodu proszącego o sojusz.
        // 2. Użyj TreasuryAdvisor, aby sprawdzić złoto rodu proszącego o sojusz.
        // 3. Jeśli armia albo złoto są za małe, wywołaj AllianceRejected(...).
        // 4. Jeśli oba warunki są spełnione, wywołaj AllianceAccepted(...).

        bool enoughArmy = _armyAdvisor.HasEnoughArmy(request.FromHouse);
        bool enoughGold = _treasuryAdvisor.HasEnoughGold(request.FromHouse);

        if (!enoughArmy)
        {
            AllianceRejected(request, "Ród ma zbyt małą armię, aby zawrzeć wiarygodny sojusz.");
            return;
        }

        if (!enoughGold)
        {
            AllianceRejected(request, "Ród ma za mało złota, aby utrzymać sojusz.");
            return;
        }

        AllianceAccepted(request);
    }

    public void AllianceAccepted(AllianceRequest request)
    {
        // TODO dla kursanta:
        // Ustaw status, decyzję rady, wyślij kruka do rodu docelowego i zapisz do archiwum.
        request.Status = "Zaakceptowany";
        request.CouncilDecision = "Mała Rada zaakceptowała propozycję sojuszu.";

        _ravenMessenger.SendRaven(request.ToHouse, request.CouncilDecision);
        _archive.Save(request);
    }

    public void AllianceRejected(AllianceRequest request, string reason)
    {
        // TODO dla kursanta:
        // Ustaw status, decyzję rady, wyślij kruka do rodu proszącego i zapisz do archiwum.
        request.Status = "Odrzucony";
        request.CouncilDecision = reason;

        _ravenMessenger.SendRaven(request.FromHouse, $"Sojusz odrzucony. Powód: {reason}");
        _archive.Save(request);
    }
}
