using SzkieletMediatorFasadaGraOTron.Models;

namespace SzkieletMediatorFasadaGraOTron.Mediators;

/// <summary>
/// Mediator: wspólny kontrakt Małej Rady.
/// Fasada będzie korzystać z tego interfejsu, a nie bezpośrednio z komponentów.
/// </summary>
public interface ICouncilMediator
{
    void SubmitAllianceRequest(AllianceRequest request);
    void AllianceAccepted(AllianceRequest request);
    void AllianceRejected(AllianceRequest request, string reason);
}
