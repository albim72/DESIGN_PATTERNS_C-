using SzkieletMediatorFasadaGraOTron.Mediators;
using SzkieletMediatorFasadaGraOTron.Models;

namespace SzkieletMediatorFasadaGraOTron.Facade;

/// <summary>
/// Fasada: proste wejście do całego procesu zawierania sojuszu.
/// Kod klienta nie musi znać kruków, doradców, archiwum ani mediatora szczegółowo.
/// </summary>
public class KingdomFacade
{
    private readonly ICouncilMediator _mediator;

    public KingdomFacade(ICouncilMediator mediator)
    {
        _mediator = mediator;
    }

    public void RequestAlliance(GreatHouse fromHouse, GreatHouse toHouse, string purpose)
    {
        // TODO dla kursanta:
        // 1. Utwórz AllianceRequest.
        // 2. Przekaż go do mediatora metodą SubmitAllianceRequest(...).
        // 3. Wypisz czytelny nagłówek procesu.

        Console.WriteLine("====================================================");
        Console.WriteLine("Fasada Królestwa: rozpoczęcie procesu sojuszu");
        Console.WriteLine("====================================================");

        AllianceRequest request = new AllianceRequest(fromHouse, toHouse, purpose);
        _mediator.SubmitAllianceRequest(request);

        Console.WriteLine();
    }
}
