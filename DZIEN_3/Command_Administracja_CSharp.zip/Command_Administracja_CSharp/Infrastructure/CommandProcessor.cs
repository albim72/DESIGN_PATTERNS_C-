using CommandAdministracja.Commands;

namespace CommandAdministracja.Infrastructure;

public class CommandProcessor
{
    private readonly List<CommandHistoryItem> _history = new();

    public IReadOnlyList<CommandHistoryItem> History => _history.AsReadOnly();

    public void Process(ICommand command)
    {
        Console.WriteLine($"--- Wykonywanie komendy: {command.Name} ---");

        try
        {
            command.Execute();
            _history.Add(new CommandHistoryItem(DateTime.Now, command.Name, true, null));
            Console.WriteLine("Komenda została wykonana i zapisana w historii.");
        }
        catch (Exception ex)
        {
            _history.Add(new CommandHistoryItem(DateTime.Now, command.Name, false, ex.Message));
            Console.WriteLine($"Błąd wykonania komendy: {ex.Message}");
        }

        Console.WriteLine();
    }

    public void PrintHistory()
    {
        Console.WriteLine("=== HISTORIA KOMEND ===");

        if (_history.Count == 0)
        {
            Console.WriteLine("Brak wykonanych komend.");
            return;
        }

        foreach (CommandHistoryItem item in _history)
        {
            string status = item.Success ? "SUKCES" : "BŁĄD";
            Console.WriteLine($"{item.ExecutedAt:yyyy-MM-dd HH:mm:ss} | {status} | {item.CommandName}");

            if (!string.IsNullOrWhiteSpace(item.ErrorMessage))
            {
                Console.WriteLine($"   Powód: {item.ErrorMessage}");
            }
        }
    }
}
