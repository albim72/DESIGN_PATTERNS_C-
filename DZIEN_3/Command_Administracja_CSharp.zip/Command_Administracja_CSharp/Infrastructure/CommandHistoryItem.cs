namespace CommandAdministracja.Infrastructure;

public record CommandHistoryItem(
    DateTime ExecutedAt,
    string CommandName,
    bool Success,
    string? ErrorMessage
);
