# Wzorzec Command w C# - przykład administracyjny

Projekt pokazuje wzorzec **Command** na przykładzie systemu obsługi wniosków administracyjnych.

## Cel przykładu

Zamiast wykonywać operacje administracyjne przez jedną dużą metodę z wieloma instrukcjami `if` albo `switch`, każda operacja zostaje zamieniona w osobny obiekt-komendę.

Przykładowe komendy:

- `ZarejestrujWniosekCommand`
- `ZatwierdzWniosekCommand`
- `OdrzucWniosekCommand`
- `WyslijPowiadomienieCommand`

Wszystkie implementują wspólny interfejs:

```csharp
public interface ICommand
{
    string Name { get; }
    void Execute();
}
```

## Struktura katalogów

```text
Command_Administracja_CSharp/
│
├── Models/
│   └── Wniosek.cs
│
├── Services/
│   └── WniosekService.cs
│
├── Commands/
│   ├── ICommand.cs
│   ├── ZarejestrujWniosekCommand.cs
│   ├── ZatwierdzWniosekCommand.cs
│   ├── OdrzucWniosekCommand.cs
│   └── WyslijPowiadomienieCommand.cs
│
├── Infrastructure/
│   ├── CommandProcessor.cs
│   └── CommandHistoryItem.cs
│
├── Docs/
│   └── Omowienie_dydaktyczne.md
│
├── Program.cs
└── Command_Administracja_CSharp.csproj
```

## Jak uruchomić

W katalogu projektu uruchom:

```bash
dotnet run
```

Wymagany jest .NET 8 SDK albo nowszy.

## Co pokazuje przykład?

1. Komenda jest obiektem reprezentującym operację.
2. Procesor komend nie zna szczegółów operacji, tylko wywołuje `Execute()`.
3. Komendy można logować, zapisywać w historii, kolejkować albo ponawiać.
4. Dodanie nowej operacji nie wymaga przerabiania głównego procesora.
5. Kod lepiej realizuje zasadę OCP: otwarte na rozszerzenie, zamknięte na modyfikację.

## Najważniejsza idea

**Command zamienia czasownik w obiekt.**

Zamiast mieć tylko metodę `Zatwierdz()`, tworzymy obiekt `ZatwierdzWniosekCommand`, który można przekazać, wykonać, zapisać w historii lub wrzucić do kolejki.
