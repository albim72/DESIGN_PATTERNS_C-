namespace CommandAdministracja.Models;

public class Wniosek
{
    public int Id { get; }
    public string Obywatel { get; }
    public string TypSprawy { get; }
    public string Status { get; set; }
    public string? PowodOdrzucenia { get; set; }

    public Wniosek(int id, string obywatel, string typSprawy)
    {
        Id = id;
        Obywatel = obywatel;
        TypSprawy = typSprawy;
        Status = "Nowy";
    }

    public override string ToString()
    {
        string opis = $"Wniosek {Id}: {TypSprawy}, obywatel: {Obywatel}, status: {Status}";

        if (!string.IsNullOrWhiteSpace(PowodOdrzucenia))
        {
            opis += $", powód odrzucenia: {PowodOdrzucenia}";
        }

        return opis;
    }
}
