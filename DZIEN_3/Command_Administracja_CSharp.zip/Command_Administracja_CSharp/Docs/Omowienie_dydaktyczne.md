# Omówienie dydaktyczne projektu Command

## Jak omawiać projekt na zajęciach?

Najlepsza kolejność:

1. `Models/Wniosek.cs`
2. `Services/WniosekService.cs`
3. `Commands/ICommand.cs`
4. Konkretne komendy w katalogu `Commands`
5. `Infrastructure/CommandProcessor.cs`
6. `Program.cs`
7. Historia komend i pytania kontrolne

---

## 1. Model: `Wniosek`

`Wniosek` reprezentuje sprawę administracyjną.

Ma:

- `Id`,
- `Obywatel`,
- `TypSprawy`,
- `Status`,
- opcjonalny `PowodOdrzucenia`.

To zwykły obiekt domenowy. Nie wie nic o wzorcu Command.

---

## 2. Serwis: `WniosekService`

Serwis wykonuje realne operacje:

- rejestruje wniosek,
- zatwierdza wniosek,
- odrzuca wniosek,
- wysyła powiadomienie,
- pokazuje status.

Serwis jest odbiorcą komend, czyli obiektem, który faktycznie wykonuje pracę.

---

## 3. Interfejs `ICommand`

To wspólny kontrakt dla wszystkich poleceń.

```csharp
public interface ICommand
{
    string Name { get; }
    void Execute();
}
```

Każda komenda musi mieć metodę `Execute()`.

---

## 4. Konkretne komendy

Każda operacja administracyjna jest osobną klasą:

- `ZarejestrujWniosekCommand`,
- `ZatwierdzWniosekCommand`,
- `OdrzucWniosekCommand`,
- `WyslijPowiadomienieCommand`.

Każda komenda przechowuje dane potrzebne do wykonania operacji.

Przykład:

```csharp
ICommand command = new ZatwierdzWniosekCommand(service, 1);
command.Execute();
```

---

## 5. Procesor komend

`CommandProcessor` dostaje dowolną komendę i wykonuje ją.

Nie musi wiedzieć, czy komenda zatwierdza, odrzuca, rejestruje czy wysyła powiadomienie.

```csharp
processor.Process(command);
```

Dodatkowo zapisuje historię wykonanych komend.

---

## 6. Program.cs

`Program.cs` pokazuje dwa scenariusze:

1. Wniosek Jana Kowalskiego zostaje zarejestrowany, zatwierdzony i obywatel dostaje powiadomienie.
2. Wniosek Anny Nowak zostaje zarejestrowany, odrzucony i obywatelka dostaje powiadomienie.
3. Na końcu program pokazuje próbę wykonania błędnej komendy, aby pokazać obsługę błędów.

---

## Najważniejsze pytania do kursantów

1. Która klasa jest wspólnym kontraktem komend?
2. Co robi metoda `Execute()`?
3. Dlaczego `CommandProcessor` nie musi znać konkretnych typów komend?
4. Gdzie znajduje się realna logika biznesowa?
5. Co zyskujemy, zapisując komendy w historii?
6. Jak dodać nową komendę, np. `ArchiwizujWniosekCommand`?
7. Dlaczego ten wzorzec pomaga uniknąć wielkiego `switch`?

---

## Puenta

Command zamienia operację w obiekt. Dzięki temu operację można wykonać teraz, później, zapisać w historii, zalogować, ponowić albo wrzucić do kolejki.
