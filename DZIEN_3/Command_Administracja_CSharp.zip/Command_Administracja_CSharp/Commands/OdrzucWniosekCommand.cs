using CommandAdministracja.Services;

namespace CommandAdministracja.Commands;

public class OdrzucWniosekCommand : ICommand
{
    private readonly WniosekService _service;
    private readonly int _wniosekId;
    private readonly string _powod;

    public string Name => $"Odrzuć wniosek #{_wniosekId}";

    public OdrzucWniosekCommand(WniosekService service, int wniosekId, string powod)
    {
        _service = service;
        _wniosekId = wniosekId;
        _powod = powod;
    }

    public void Execute()
    {
        _service.Odrzuc(_wniosekId, _powod);
    }
}
