using CommandAdministracja.Models;
using CommandAdministracja.Services;

namespace CommandAdministracja.Commands;

public class ZarejestrujWniosekCommand : ICommand
{
    private readonly WniosekService _service;
    private readonly Wniosek _wniosek;

    public string Name => $"Zarejestruj wniosek #{_wniosek.Id}";

    public ZarejestrujWniosekCommand(WniosekService service, Wniosek wniosek)
    {
        _service = service;
        _wniosek = wniosek;
    }

    public void Execute()
    {
        _service.Zarejestruj(_wniosek);
    }
}
