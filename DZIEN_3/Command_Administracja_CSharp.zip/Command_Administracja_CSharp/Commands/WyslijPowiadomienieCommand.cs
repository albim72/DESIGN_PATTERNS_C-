using CommandAdministracja.Services;

namespace CommandAdministracja.Commands;

public class WyslijPowiadomienieCommand : ICommand
{
    private readonly WniosekService _service;
    private readonly int _wniosekId;
    private readonly string _tresc;

    public string Name => $"Wyślij powiadomienie dla wniosku #{_wniosekId}";

    public WyslijPowiadomienieCommand(WniosekService service, int wniosekId, string tresc)
    {
        _service = service;
        _wniosekId = wniosekId;
        _tresc = tresc;
    }

    public void Execute()
    {
        _service.WyslijPowiadomienie(_wniosekId, _tresc);
    }
}
