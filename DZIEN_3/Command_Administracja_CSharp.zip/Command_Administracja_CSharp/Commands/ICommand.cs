namespace CommandAdministracja.Commands;

public interface ICommand
{
    string Name { get; }
    void Execute();
}
