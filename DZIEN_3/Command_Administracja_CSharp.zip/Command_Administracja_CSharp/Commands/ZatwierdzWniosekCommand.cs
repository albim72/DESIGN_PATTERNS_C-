using CommandAdministracja.Services;

namespace CommandAdministracja.Commands;

public class ZatwierdzWniosekCommand : ICommand
{
    private readonly WniosekService _service;
    private readonly int _wniosekId;

    public string Name => $"Zatwierdź wniosek #{_wniosekId}";

    public ZatwierdzWniosekCommand(WniosekService service, int wniosekId)
    {
        _service = service;
        _wniosekId = wniosekId;
    }

    public void Execute()
    {
        _service.Zatwierdz(_wniosekId);
    }
}
