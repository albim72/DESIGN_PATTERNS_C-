using CommandAdministracja.Commands;
using CommandAdministracja.Infrastructure;
using CommandAdministracja.Models;
using CommandAdministracja.Services;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.WriteLine("WZORZEC COMMAND - PRZYKŁAD ADMINISTRACYJNY");
Console.WriteLine("System obsługi wniosków administracyjnych");
Console.WriteLine();

WniosekService service = new WniosekService();
CommandProcessor processor = new CommandProcessor();

Wniosek wniosekEmerytalny = new(
    id: 1,
    obywatel: "Jan Kowalski",
    typSprawy: "Świadczenie emerytalne"
);

ICommand zarejestrujEmerytalny = new ZarejestrujWniosekCommand(service, wniosekEmerytalny);
ICommand zatwierdzEmerytalny = new ZatwierdzWniosekCommand(service, 1);
ICommand powiadomEmerytalny = new WyslijPowiadomienieCommand(
    service,
    1,
    "Pański wniosek został zatwierdzony. Decyzja zostanie doręczona pocztą."
);

processor.Process(zarejestrujEmerytalny);
processor.Process(zatwierdzEmerytalny);
processor.Process(powiadomEmerytalny);
service.PokazStatus(1);

Console.WriteLine();
Console.WriteLine("====================================================");
Console.WriteLine();

Wniosek wniosekMieszkaniowy = new(
    id: 2,
    obywatel: "Anna Nowak",
    typSprawy: "Dodatek mieszkaniowy"
);

ICommand zarejestrujMieszkaniowy = new ZarejestrujWniosekCommand(service, wniosekMieszkaniowy);
ICommand odrzucMieszkaniowy = new OdrzucWniosekCommand(
    service,
    2,
    "Brak wymaganego załącznika potwierdzającego dochód."
);
ICommand powiadomMieszkaniowy = new WyslijPowiadomienieCommand(
    service,
    2,
    "Wniosek został odrzucony. Szczegóły znajdują się w uzasadnieniu decyzji."
);

processor.Process(zarejestrujMieszkaniowy);
processor.Process(odrzucMieszkaniowy);
processor.Process(powiadomMieszkaniowy);
service.PokazStatus(2);

Console.WriteLine();
Console.WriteLine("====================================================");
Console.WriteLine();

// Przykład błędnej komendy: próba odrzucenia wniosku już zatwierdzonego.
ICommand blednaKomenda = new OdrzucWniosekCommand(
    service,
    1,
    "Próba odrzucenia po zatwierdzeniu."
);

processor.Process(blednaKomenda);

processor.PrintHistory();
