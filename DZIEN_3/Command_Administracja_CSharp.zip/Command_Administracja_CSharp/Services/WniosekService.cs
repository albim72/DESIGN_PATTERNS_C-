using CommandAdministracja.Models;

namespace CommandAdministracja.Services;

public class WniosekService
{
    private readonly Dictionary<int, Wniosek> _wnioski = new();

    public void Zarejestruj(Wniosek wniosek)
    {
        if (_wnioski.ContainsKey(wniosek.Id))
        {
            throw new InvalidOperationException($"Wniosek o ID {wniosek.Id} już istnieje w systemie.");
        }

        wniosek.Status = "Zarejestrowany";
        _wnioski[wniosek.Id] = wniosek;

        Console.WriteLine($"Zarejestrowano wniosek {wniosek.Id}: {wniosek.TypSprawy}");
    }

    public void Zatwierdz(int id)
    {
        Wniosek wniosek = PobierzWniosek(id);

        if (wniosek.Status == "Odrzucony")
        {
            throw new InvalidOperationException("Nie można zatwierdzić wniosku, który został już odrzucony.");
        }

        wniosek.Status = "Zatwierdzony";
        Console.WriteLine($"Zatwierdzono wniosek {wniosek.Id} obywatela: {wniosek.Obywatel}");
    }

    public void Odrzuc(int id, string powod)
    {
        Wniosek wniosek = PobierzWniosek(id);

        if (wniosek.Status == "Zatwierdzony")
        {
            throw new InvalidOperationException("Nie można odrzucić wniosku, który został już zatwierdzony.");
        }

        wniosek.Status = "Odrzucony";
        wniosek.PowodOdrzucenia = powod;

        Console.WriteLine($"Odrzucono wniosek {wniosek.Id}. Powód: {powod}");
    }

    public void WyslijPowiadomienie(int id, string tresc)
    {
        Wniosek wniosek = PobierzWniosek(id);
        Console.WriteLine($"Wysłano powiadomienie do obywatela {wniosek.Obywatel}: {tresc}");
    }

    public void PokazStatus(int id)
    {
        Wniosek wniosek = PobierzWniosek(id);
        Console.WriteLine(wniosek);
    }

    private Wniosek PobierzWniosek(int id)
    {
        if (!_wnioski.TryGetValue(id, out Wniosek? wniosek))
        {
            throw new KeyNotFoundException($"Nie znaleziono wniosku o ID {id}.");
        }

        return wniosek;
    }
}
