# Omówienie dydaktyczne wzorca Interpreter

## Kolejność omawiania plików

1. `Interpreter_Administracja_CSharp.sln` - pokaż, że mamy dwa projekty.
2. `InterpreterRules/InterpreterRules.csproj` - biblioteka z regułami.
3. `InterpreterRunner/InterpreterRunner.csproj` - aplikacja konsolowa z referencją do biblioteki.
4. `InterpreterRules/Models/ApplicationContext.cs` - Context wzorca Interpreter.
5. `InterpreterRules/Expressions/IExpression.cs` - Abstract Expression.
6. Terminal Expressions:
   - `AgeGreaterOrEqualExpression.cs`
   - `DocumentsCompleteExpression.cs`
   - `CityExpression.cs`
   - `IncomeLessThanExpression.cs`
   - `CaseTypeExpression.cs`
7. Nonterminal Expressions:
   - `AndExpression.cs`
   - `OrExpression.cs`
   - `NotExpression.cs`
8. `InterpreterRules/Parser/AdministrativeRuleFactory.cs` - budowanie gotowych drzew reguł.
9. `InterpreterRunner/Program.cs` - uruchomienie reguł na danych przykładowych.

## Główna idea

Interpreter służy do reprezentowania małego języka reguł jako drzewa obiektów.

Przykład:

```text
wiek >= 60 AND dokumenty kompletne AND typ sprawy == "Świadczenie senioralne"
```

W kodzie jest to zbudowane jako drzewo wyrażeń:

```text
AND
├── AgeGreaterOrEqualExpression(60)
└── AND
    ├── DocumentsCompleteExpression
    └── CaseTypeExpression("Świadczenie senioralne")
```

## Najważniejsza puenta

Interpreter nie jest potrzebny do jednego prostego `if`. Ma sens wtedy, gdy w systemie pojawia się mały język warunków, filtrów lub reguł biznesowych.
