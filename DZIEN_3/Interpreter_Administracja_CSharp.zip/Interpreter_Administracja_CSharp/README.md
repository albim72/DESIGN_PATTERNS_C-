# Interpreter Administracja C#

Przykład dydaktyczny wzorca projektowego **Interpreter** w C#.

## Struktura rozwiązania

Rozwiązanie składa się z dwóch projektów:

1. `InterpreterRules` - biblioteka klas zawierająca model, wyrażenia i fabrykę reguł.
2. `InterpreterRunner` - aplikacja konsolowa, która uruchamia bibliotekę `InterpreterRules`.

Projekt `InterpreterRunner` ma referencję do projektu `InterpreterRules`.

## Uruchomienie

W katalogu głównym rozwiązania:

```bash
dotnet run --project InterpreterRunner
```

Albo w Visual Studio:

1. Otwórz `Interpreter_Administracja_CSharp.sln`.
2. Ustaw `InterpreterRunner` jako projekt startowy.
3. Uruchom projekt.

## Sens przykładu

System interpretuje reguły administracyjne, np.:

- wiek >= 60 AND dokumenty kompletne AND typ sprawy == "Świadczenie senioralne"
- dochód < 3000 AND dokumenty kompletne AND (miasto == "Lublin" OR miasto == "Warszawa")
- NOT dokumenty kompletne

Każda część reguły jest osobną klasą implementującą `IExpression`.
