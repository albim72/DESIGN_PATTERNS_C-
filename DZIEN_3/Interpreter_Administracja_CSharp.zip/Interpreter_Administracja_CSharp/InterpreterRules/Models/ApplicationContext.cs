namespace InterpreterRules.Models;

/// <summary>
/// Context wzorca Interpreter: dane wniosku/sprawy administracyjnej,
/// na których interpretowane są reguły biznesowe.
/// </summary>
public class ApplicationContext
{
    public string CitizenName { get; }
    public int Age { get; }
    public string City { get; }
    public bool DocumentsComplete { get; }
    public decimal Income { get; }
    public string CaseType { get; }

    public ApplicationContext(
        string citizenName,
        int age,
        string city,
        bool documentsComplete,
        decimal income,
        string caseType)
    {
        CitizenName = citizenName;
        Age = age;
        City = city;
        DocumentsComplete = documentsComplete;
        Income = income;
        CaseType = caseType;
    }

    public override string ToString()
    {
        return $"{CitizenName}, wiek: {Age}, miasto: {City}, " +
               $"dokumenty kompletne: {DocumentsComplete}, dochód: {Income:C}, sprawa: {CaseType}";
    }
}
