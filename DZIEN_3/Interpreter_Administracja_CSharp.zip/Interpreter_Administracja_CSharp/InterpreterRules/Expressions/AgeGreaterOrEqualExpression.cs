using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Terminal Expression: prosty warunek wieku.
/// </summary>
public class AgeGreaterOrEqualExpression : IExpression
{
    private readonly int _requiredAge;

    public AgeGreaterOrEqualExpression(int requiredAge)
    {
        _requiredAge = requiredAge;
    }

    public string Description => $"wiek >= {_requiredAge}";

    public bool Interpret(ApplicationContext context)
    {
        return context.Age >= _requiredAge;
    }
}
