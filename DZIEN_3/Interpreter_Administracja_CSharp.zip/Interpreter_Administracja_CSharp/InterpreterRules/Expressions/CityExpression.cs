using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Terminal Expression: sprawdza wymagane miasto.
/// </summary>
public class CityExpression : IExpression
{
    private readonly string _requiredCity;

    public CityExpression(string requiredCity)
    {
        _requiredCity = requiredCity;
    }

    public string Description => $"miasto == '{_requiredCity}'";

    public bool Interpret(ApplicationContext context)
    {
        return string.Equals(context.City, _requiredCity, StringComparison.OrdinalIgnoreCase);
    }
}
