using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Terminal Expression: sprawdza limit dochodu.
/// </summary>
public class IncomeLessThanExpression : IExpression
{
    private readonly decimal _limit;

    public IncomeLessThanExpression(decimal limit)
    {
        _limit = limit;
    }

    public string Description => $"dochód < {_limit}";

    public bool Interpret(ApplicationContext context)
    {
        return context.Income < _limit;
    }
}
