using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Abstract Expression: wspólny kontrakt dla wszystkich wyrażeń reguły.
/// </summary>
public interface IExpression
{
    string Description { get; }
    bool Interpret(ApplicationContext context);
}
