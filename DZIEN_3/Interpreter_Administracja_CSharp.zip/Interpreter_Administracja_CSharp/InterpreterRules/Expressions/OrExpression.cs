using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Nonterminal Expression: łączy dwa wyrażenia operatorem OR.
/// </summary>
public class OrExpression : IExpression
{
    private readonly IExpression _left;
    private readonly IExpression _right;

    public OrExpression(IExpression left, IExpression right)
    {
        _left = left;
        _right = right;
    }

    public string Description => $"({_left.Description} OR {_right.Description})";

    public bool Interpret(ApplicationContext context)
    {
        return _left.Interpret(context) || _right.Interpret(context);
    }
}
