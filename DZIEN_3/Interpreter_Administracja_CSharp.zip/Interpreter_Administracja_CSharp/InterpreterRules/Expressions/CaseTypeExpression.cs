using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Terminal Expression: sprawdza typ sprawy administracyjnej.
/// </summary>
public class CaseTypeExpression : IExpression
{
    private readonly string _requiredCaseType;

    public CaseTypeExpression(string requiredCaseType)
    {
        _requiredCaseType = requiredCaseType;
    }

    public string Description => $"typ sprawy == '{_requiredCaseType}'";

    public bool Interpret(ApplicationContext context)
    {
        return string.Equals(context.CaseType, _requiredCaseType, StringComparison.OrdinalIgnoreCase);
    }
}
