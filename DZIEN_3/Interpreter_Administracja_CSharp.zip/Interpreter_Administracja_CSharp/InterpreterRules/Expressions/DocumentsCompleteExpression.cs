using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Terminal Expression: sprawdza kompletność dokumentów.
/// </summary>
public class DocumentsCompleteExpression : IExpression
{
    public string Description => "dokumenty kompletne";

    public bool Interpret(ApplicationContext context)
    {
        return context.DocumentsComplete;
    }
}
