using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Nonterminal Expression: łączy dwa wyrażenia operatorem AND.
/// </summary>
public class AndExpression : IExpression
{
    private readonly IExpression _left;
    private readonly IExpression _right;

    public AndExpression(IExpression left, IExpression right)
    {
        _left = left;
        _right = right;
    }

    public string Description => $"({_left.Description} AND {_right.Description})";

    public bool Interpret(ApplicationContext context)
    {
        return _left.Interpret(context) && _right.Interpret(context);
    }
}
