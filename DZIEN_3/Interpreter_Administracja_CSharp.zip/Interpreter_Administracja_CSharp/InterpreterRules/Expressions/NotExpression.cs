using InterpreterRules.Models;

namespace InterpreterRules.Expressions;

/// <summary>
/// Nonterminal Expression: neguje wynik innego wyrażenia.
/// </summary>
public class NotExpression : IExpression
{
    private readonly IExpression _inner;

    public NotExpression(IExpression inner)
    {
        _inner = inner;
    }

    public string Description => $"NOT ({_inner.Description})";

    public bool Interpret(ApplicationContext context)
    {
        return !_inner.Interpret(context);
    }
}
