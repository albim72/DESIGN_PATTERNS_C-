using InterpreterRules.Expressions;

namespace InterpreterRules.Parser;

/// <summary>
/// Pomocnicza fabryka gotowych reguł administracyjnych.
/// Nie jest pełnym parserem tekstowym. Buduje drzewa wyrażeń wzorca Interpreter.
/// </summary>
public static class AdministrativeRuleFactory
{
    /// <summary>
    /// Reguła: świadczenie senioralne.
    /// Obywatel kwalifikuje się, jeśli ma co najmniej 60 lat,
    /// ma komplet dokumentów i typ sprawy to "Świadczenie senioralne".
    /// </summary>
    public static IExpression SeniorBenefitRule()
    {
        return new AndExpression(
            new AgeGreaterOrEqualExpression(60),
            new AndExpression(
                new DocumentsCompleteExpression(),
                new CaseTypeExpression("Świadczenie senioralne")
            )
        );
    }

    /// <summary>
    /// Reguła: dodatek mieszkaniowy.
    /// Obywatel kwalifikuje się, jeśli dochód jest niższy niż 3000,
    /// dokumenty są kompletne i mieszka w Lublinie albo Warszawie.
    /// </summary>
    public static IExpression HousingBenefitRule()
    {
        return new AndExpression(
            new IncomeLessThanExpression(3000m),
            new AndExpression(
                new DocumentsCompleteExpression(),
                new OrExpression(
                    new CityExpression("Lublin"),
                    new CityExpression("Warszawa")
                )
            )
        );
    }

    /// <summary>
    /// Reguła przykładowa: sprawa wymaga uzupełnienia, jeśli dokumenty NIE są kompletne.
    /// </summary>
    public static IExpression RequiresCompletionRule()
    {
        return new NotExpression(new DocumentsCompleteExpression());
    }
}
