using InterpreterRules.Expressions;
using InterpreterRules.Models;
using InterpreterRules.Parser;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.WriteLine("==============================================");
Console.WriteLine(" WZORZEC INTERPRETER - SYSTEM ADMINISTRACYJNY");
Console.WriteLine("==============================================");
Console.WriteLine();

List<ApplicationContext> applications = new()
{
    new ApplicationContext(
        citizenName: "Jan Kowalski",
        age: 67,
        city: "Lublin",
        documentsComplete: true,
        income: 2800m,
        caseType: "Świadczenie senioralne"),

    new ApplicationContext(
        citizenName: "Anna Nowak",
        age: 42,
        city: "Warszawa",
        documentsComplete: true,
        income: 2450m,
        caseType: "Dodatek mieszkaniowy"),

    new ApplicationContext(
        citizenName: "Piotr Zieliński",
        age: 58,
        city: "Kraków",
        documentsComplete: false,
        income: 4100m,
        caseType: "Świadczenie senioralne")
};

IExpression seniorBenefitRule = AdministrativeRuleFactory.SeniorBenefitRule();
IExpression housingBenefitRule = AdministrativeRuleFactory.HousingBenefitRule();
IExpression requiresCompletionRule = AdministrativeRuleFactory.RequiresCompletionRule();

EvaluateRule("Reguła świadczenia senioralnego", seniorBenefitRule, applications);
EvaluateRule("Reguła dodatku mieszkaniowego", housingBenefitRule, applications);
EvaluateRule("Reguła wezwania do uzupełnienia dokumentów", requiresCompletionRule, applications);

Console.WriteLine("KONIEC DEMONSTRACJI");

static void EvaluateRule(string title, IExpression rule, IEnumerable<ApplicationContext> applications)
{
    Console.WriteLine($"--- {title} ---");
    Console.WriteLine($"Drzewo reguły: {rule.Description}");
    Console.WriteLine();

    foreach (ApplicationContext application in applications)
    {
        bool result = rule.Interpret(application);
        string decision = result ? "SPEŁNIA" : "NIE SPEŁNIA";

        Console.WriteLine(application);
        Console.WriteLine($"Wynik interpretacji: {decision}");
        Console.WriteLine();
    }

    Console.WriteLine();
}
