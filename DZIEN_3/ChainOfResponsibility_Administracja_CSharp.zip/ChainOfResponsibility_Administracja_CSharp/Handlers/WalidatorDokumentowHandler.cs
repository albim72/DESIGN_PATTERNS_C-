using ChainOfResponsibilityAdministracja.Models;

namespace ChainOfResponsibilityAdministracja.Handlers;

/// <summary>
/// Drugi etap łańcucha: sprawdzenie kompletności dokumentów.
/// </summary>
public class WalidatorDokumentowHandler : WniosekHandlerBase
{
    public override void Handle(Wniosek wniosek)
    {
        Console.WriteLine("2. Walidacja dokumentów: sprawdzam kompletność załączników...");

        if (!wniosek.DokumentyKompletne)
        {
            Stop(
                wniosek,
                "Do uzupełnienia",
                "Wniosek zatrzymany: dokumenty są niekompletne. Należy wysłać wezwanie do uzupełnienia braków.");
            return;
        }

        Console.WriteLine("Dokumenty są kompletne.");
        base.Handle(wniosek);
    }
}
