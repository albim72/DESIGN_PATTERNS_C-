using ChainOfResponsibilityAdministracja.Models;

namespace ChainOfResponsibilityAdministracja.Handlers;

/// <summary>
/// Pierwszy etap łańcucha: sprawdzenie podstawowych danych formalnych.
/// </summary>
public class WalidatorFormalnyHandler : WniosekHandlerBase
{
    public override void Handle(Wniosek wniosek)
    {
        Console.WriteLine("1. Walidacja formalna: sprawdzam obywatela i PESEL...");

        if (string.IsNullOrWhiteSpace(wniosek.Obywatel))
        {
            Stop(wniosek, "Odrzucony", "Wniosek odrzucony: brak danych obywatela.");
            return;
        }

        if (string.IsNullOrWhiteSpace(wniosek.Pesel) || wniosek.Pesel.Length != 11)
        {
            Stop(wniosek, "Odrzucony", "Wniosek odrzucony: PESEL jest pusty albo ma nieprawidłową długość.");
            return;
        }

        Console.WriteLine("Dane formalne są poprawne.");
        base.Handle(wniosek);
    }
}
