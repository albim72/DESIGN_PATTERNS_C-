using ChainOfResponsibilityAdministracja.Models;

namespace ChainOfResponsibilityAdministracja.Handlers;

/// <summary>
/// Ostatni etap łańcucha: rejestracja zaakceptowanego wniosku.
/// </summary>
public class RejestracjaWnioskuHandler : WniosekHandlerBase
{
    public override void Handle(Wniosek wniosek)
    {
        Console.WriteLine("5. Rejestracja: zapisuję wniosek w systemie spraw...");

        wniosek.Status = "Przyjęty do realizacji";
        wniosek.Komunikat = $"Wniosek #{wniosek.Id} został przyjęty do realizacji.";

        Console.WriteLine(wniosek.Komunikat);
        base.Handle(wniosek);
    }
}
