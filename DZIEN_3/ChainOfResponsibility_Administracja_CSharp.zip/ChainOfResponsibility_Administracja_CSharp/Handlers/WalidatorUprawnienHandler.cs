using ChainOfResponsibilityAdministracja.Models;

namespace ChainOfResponsibilityAdministracja.Handlers;

/// <summary>
/// Trzeci etap łańcucha: sprawdzenie prawa do świadczenia/usługi.
/// </summary>
public class WalidatorUprawnienHandler : WniosekHandlerBase
{
    public override void Handle(Wniosek wniosek)
    {
        Console.WriteLine("3. Walidacja uprawnień: sprawdzam warunki merytoryczne...");

        if (!wniosek.MaUprawnienia)
        {
            Stop(
                wniosek,
                "Odrzucony",
                "Wniosek odrzucony: obywatel nie spełnia warunków dla tego typu sprawy.");
            return;
        }

        Console.WriteLine("Uprawnienia zostały potwierdzone.");
        base.Handle(wniosek);
    }
}
