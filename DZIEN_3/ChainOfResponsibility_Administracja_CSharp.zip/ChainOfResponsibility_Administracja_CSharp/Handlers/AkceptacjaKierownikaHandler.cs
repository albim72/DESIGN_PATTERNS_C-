using ChainOfResponsibilityAdministracja.Models;

namespace ChainOfResponsibilityAdministracja.Handlers;

/// <summary>
/// Czwarty etap łańcucha: opcjonalna akceptacja kierownika.
/// </summary>
public class AkceptacjaKierownikaHandler : WniosekHandlerBase
{
    public override void Handle(Wniosek wniosek)
    {
        Console.WriteLine("4. Akceptacja kierownika: sprawdzam, czy sprawa wymaga dodatkowej akceptacji...");

        if (wniosek.WymagaAkceptacjiKierownika)
        {
            Console.WriteLine("Sprawa wymaga akceptacji kierownika. Symulacja: kierownik zaakceptował sprawę.");
        }
        else
        {
            Console.WriteLine("Akceptacja kierownika nie jest wymagana.");
        }

        base.Handle(wniosek);
    }
}
