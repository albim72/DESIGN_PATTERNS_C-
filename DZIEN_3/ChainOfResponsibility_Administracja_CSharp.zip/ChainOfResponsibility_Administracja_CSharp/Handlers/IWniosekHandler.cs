using ChainOfResponsibilityAdministracja.Models;

namespace ChainOfResponsibilityAdministracja.Handlers;

/// <summary>
/// Handler we wzorcu Chain of Responsibility.
/// Każdy element łańcucha może obsłużyć wniosek albo przekazać go dalej.
/// </summary>
public interface IWniosekHandler
{
    IWniosekHandler SetNext(IWniosekHandler next);
    void Handle(Wniosek wniosek);
}
