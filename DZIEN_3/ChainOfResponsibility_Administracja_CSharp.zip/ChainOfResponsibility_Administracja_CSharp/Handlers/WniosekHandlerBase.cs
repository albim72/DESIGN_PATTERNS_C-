using ChainOfResponsibilityAdministracja.Models;

namespace ChainOfResponsibilityAdministracja.Handlers;

/// <summary>
/// Bazowa klasa handlera. Przechowuje referencję do następnego elementu łańcucha.
/// </summary>
public abstract class WniosekHandlerBase : IWniosekHandler
{
    private IWniosekHandler? _next;

    public IWniosekHandler SetNext(IWniosekHandler next)
    {
        _next = next;
        return next;
    }

    public virtual void Handle(Wniosek wniosek)
    {
        if (_next is not null)
        {
            _next.Handle(wniosek);
        }
    }

    protected static void Stop(Wniosek wniosek, string status, string komunikat)
    {
        wniosek.Status = status;
        wniosek.Komunikat = komunikat;
        Console.WriteLine(komunikat);
        Console.WriteLine("Łańcuch został zatrzymany.");
    }
}
