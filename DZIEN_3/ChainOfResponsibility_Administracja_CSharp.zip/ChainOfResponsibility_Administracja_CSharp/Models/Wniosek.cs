namespace ChainOfResponsibilityAdministracja.Models;

/// <summary>
/// Model wniosku administracyjnego.
/// Obiekt przechodzi przez kolejne elementy łańcucha odpowiedzialności.
/// </summary>
public class Wniosek
{
    public int Id { get; }
    public string Obywatel { get; }
    public string Pesel { get; }
    public string TypSprawy { get; }
    public bool DokumentyKompletne { get; }
    public bool MaUprawnienia { get; }
    public bool WymagaAkceptacjiKierownika { get; }
    public string Status { get; set; }
    public string? Komunikat { get; set; }

    public Wniosek(
        int id,
        string obywatel,
        string pesel,
        string typSprawy,
        bool dokumentyKompletne,
        bool maUprawnienia,
        bool wymagaAkceptacjiKierownika)
    {
        Id = id;
        Obywatel = obywatel;
        Pesel = pesel;
        TypSprawy = typSprawy;
        DokumentyKompletne = dokumentyKompletne;
        MaUprawnienia = maUprawnienia;
        WymagaAkceptacjiKierownika = wymagaAkceptacjiKierownika;
        Status = "Nowy";
    }

    public override string ToString()
    {
        return $"Wniosek #{Id}, obywatel: {Obywatel}, PESEL: {Pesel}, typ sprawy: {TypSprawy}, status: {Status}";
    }
}
