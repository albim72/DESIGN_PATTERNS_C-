# Chain of Responsibility w C# - przykład administracyjny

Projekt pokazuje wzorzec **Łańcuch odpowiedzialności** na przykładzie obsługi wniosku administracyjnego.

Wniosek przechodzi przez kolejne etapy:

1. `WalidatorFormalnyHandler` - sprawdza dane obywatela i PESEL.
2. `WalidatorDokumentowHandler` - sprawdza kompletność dokumentów.
3. `WalidatorUprawnienHandler` - sprawdza uprawnienia merytoryczne.
4. `AkceptacjaKierownikaHandler` - opcjonalna akceptacja kierownika.
5. `RejestracjaWnioskuHandler` - rejestracja sprawy w systemie.

Każdy handler może:

- obsłużyć swój etap,
- przekazać wniosek dalej,
- zatrzymać łańcuch, jeśli warunek nie jest spełniony.

## Uruchomienie

```bash
dotnet run
```

## Struktura

```text
ChainOfResponsibility_Administracja_CSharp/
├── Models/
│   └── Wniosek.cs
├── Handlers/
│   ├── IWniosekHandler.cs
│   ├── WniosekHandlerBase.cs
│   ├── WalidatorFormalnyHandler.cs
│   ├── WalidatorDokumentowHandler.cs
│   ├── WalidatorUprawnienHandler.cs
│   ├── AkceptacjaKierownikaHandler.cs
│   └── RejestracjaWnioskuHandler.cs
├── Infrastructure/
│   └── WniosekProcessor.cs
├── Docs/
│   └── Omowienie_dydaktyczne.md
├── Program.cs
└── ChainOfResponsibility_Administracja_CSharp.csproj
```

## Główna idea

`Program.cs` składa łańcuch:

```csharp
formalny
    .SetNext(dokumenty)
    .SetNext(uprawnienia)
    .SetNext(akceptacjaKierownika)
    .SetNext(rejestracja);
```

Następnie uruchamia tylko pierwszy handler:

```csharp
processor.Process(wniosek);
```

Kolejne elementy łańcucha same decydują, czy przekazać wniosek dalej.
