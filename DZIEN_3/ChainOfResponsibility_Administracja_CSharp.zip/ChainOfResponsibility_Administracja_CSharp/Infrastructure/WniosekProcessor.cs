using ChainOfResponsibilityAdministracja.Handlers;
using ChainOfResponsibilityAdministracja.Models;

namespace ChainOfResponsibilityAdministracja.Infrastructure;

/// <summary>
/// Klasa pomocnicza uruchamiająca pierwszy element łańcucha.
/// Dzięki niej Program.cs jest czystszy.
/// </summary>
public class WniosekProcessor
{
    private readonly IWniosekHandler _firstHandler;

    public WniosekProcessor(IWniosekHandler firstHandler)
    {
        _firstHandler = firstHandler;
    }

    public void Process(Wniosek wniosek)
    {
        Console.WriteLine("====================================================");
        Console.WriteLine($"START OBSŁUGI: {wniosek}");
        Console.WriteLine("====================================================");

        _firstHandler.Handle(wniosek);

        Console.WriteLine("----------------------------------------------------");
        Console.WriteLine($"KONIEC OBSŁUGI: status końcowy = {wniosek.Status}");
        if (!string.IsNullOrWhiteSpace(wniosek.Komunikat))
        {
            Console.WriteLine($"Komunikat: {wniosek.Komunikat}");
        }
        Console.WriteLine();
    }
}
