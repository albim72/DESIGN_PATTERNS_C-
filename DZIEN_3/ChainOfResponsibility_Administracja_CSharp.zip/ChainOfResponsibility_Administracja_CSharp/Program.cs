using ChainOfResponsibilityAdministracja.Handlers;
using ChainOfResponsibilityAdministracja.Infrastructure;
using ChainOfResponsibilityAdministracja.Models;

Console.OutputEncoding = System.Text.Encoding.UTF8;

Console.WriteLine("WZORZEC CHAIN OF RESPONSIBILITY - SYSTEM ADMINISTRACYJNY");
Console.WriteLine();

// 1. Tworzymy elementy łańcucha.
IWniosekHandler formalny = new WalidatorFormalnyHandler();
IWniosekHandler dokumenty = new WalidatorDokumentowHandler();
IWniosekHandler uprawnienia = new WalidatorUprawnienHandler();
IWniosekHandler akceptacjaKierownika = new AkceptacjaKierownikaHandler();
IWniosekHandler rejestracja = new RejestracjaWnioskuHandler();

// 2. Składamy łańcuch odpowiedzialności.
// Wniosek przejdzie kolejno przez każdy etap, o ile żaden etap go nie zatrzyma.
formalny
    .SetNext(dokumenty)
    .SetNext(uprawnienia)
    .SetNext(akceptacjaKierownika)
    .SetNext(rejestracja);

WniosekProcessor processor = new(formalny);

// 3. Przygotowujemy przykładowe wnioski administracyjne.
List<Wniosek> wnioski = new()
{
    new Wniosek(
        id: 1,
        obywatel: "Jan Kowalski",
        pesel: "44051401359",
        typSprawy: "Świadczenie emerytalne",
        dokumentyKompletne: true,
        maUprawnienia: true,
        wymagaAkceptacjiKierownika: false),

    new Wniosek(
        id: 2,
        obywatel: "Anna Nowak",
        pesel: "12345678901",
        typSprawy: "Dodatek mieszkaniowy",
        dokumentyKompletne: false,
        maUprawnienia: true,
        wymagaAkceptacjiKierownika: false),

    new Wniosek(
        id: 3,
        obywatel: "Piotr Zieliński",
        pesel: "99999999999",
        typSprawy: "Świadczenie specjalne",
        dokumentyKompletne: true,
        maUprawnienia: false,
        wymagaAkceptacjiKierownika: true),

    new Wniosek(
        id: 4,
        obywatel: "Maria Wiśniewska",
        pesel: "11122233344",
        typSprawy: "Sprawa wymagająca akceptacji",
        dokumentyKompletne: true,
        maUprawnienia: true,
        wymagaAkceptacjiKierownika: true),

    new Wniosek(
        id: 5,
        obywatel: "",
        pesel: "22233344455",
        typSprawy: "Niekompletny wniosek formalny",
        dokumentyKompletne: true,
        maUprawnienia: true,
        wymagaAkceptacjiKierownika: false)
};

// 4. Uruchamiamy obsługę każdego wniosku.
foreach (Wniosek wniosek in wnioski)
{
    processor.Process(wniosek);
}

Console.WriteLine("Koniec demonstracji.");
Console.WriteLine("Zauważ: Program.cs uruchamia tylko pierwszy handler. Reszta dzieje się w łańcuchu.");
