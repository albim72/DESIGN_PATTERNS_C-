# Omówienie dydaktyczne: Chain of Responsibility

## Co robi aplikacja?

Aplikacja symuluje obsługę wniosków administracyjnych. Każdy wniosek przechodzi przez łańcuch etapów:

1. Walidacja formalna.
2. Walidacja dokumentów.
3. Walidacja uprawnień.
4. Akceptacja kierownika.
5. Rejestracja sprawy.

Jeżeli któryś etap wykryje problem, zatrzymuje łańcuch.

## Co jest wzorcem?

- `IWniosekHandler` - wspólny interfejs handlerów.
- `WniosekHandlerBase` - bazowa klasa przechowująca następny handler.
- `WalidatorFormalnyHandler`, `WalidatorDokumentowHandler`, `WalidatorUprawnienHandler`, `AkceptacjaKierownikaHandler`, `RejestracjaWnioskuHandler` - konkretne ogniwa łańcucha.
- `Program.cs` - klient, który składa łańcuch i uruchamia pierwszy element.

## Najważniejsza linia

```csharp
base.Handle(wniosek);
```

Ta linia przekazuje wniosek do następnego handlera. Jeżeli handler jej nie wywoła, łańcuch zatrzymuje się.

## Jak demonstrować?

1. Pokaż `Wniosek.cs` jako model danych.
2. Pokaż `IWniosekHandler.cs` jako kontrakt.
3. Pokaż `WniosekHandlerBase.cs`, szczególnie `SetNext()` i `Handle()`.
4. Pokaż każdy handler osobno.
5. W `Program.cs` pokaż składanie łańcucha przez `SetNext()`.
6. Uruchom program i pokaż, że różne wnioski zatrzymują się na różnych etapach.

## Pytania kontrolne

1. Który plik zawiera wspólny interfejs handlerów?
2. Co robi `SetNext()`?
3. Co się stanie, jeśli handler nie wywoła `base.Handle(wniosek)`?
4. Który handler zatrzymuje wniosek z niekompletnymi dokumentami?
5. Jak dodać nowy etap, np. kontrolę antyfraudową?
6. Dlaczego to rozwiązanie jest lepsze od jednej wielkiej metody z wieloma `if`?
